using System;
using resultAll;
using System.Collections;

namespace requestAll
{


    class QueryPrescriptionFileForPartnerRequest : IRequest<QueryPrescriptionFileForPartnerResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "queryPrescriptionFileForPartner";
        private String apiId = "b4dd4ece39703453b4c1171022110903";

        private long? sellerId;
        private String tradeId;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getTradeId()
        {
            return tradeId;
        }

        public void setTradeId(String tradeId)
        {
            this.tradeId = tradeId;
        }



        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(tradeId);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(QueryPrescriptionFileForPartnerResult);
        }

    }
}