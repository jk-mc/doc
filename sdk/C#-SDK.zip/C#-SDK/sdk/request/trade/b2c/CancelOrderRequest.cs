using System;
using resultAll;
using System.Collections;

namespace requestAll
{

    
    class CancelOrderRequest : IRequest<CancelOrderResult>{ 
        private String apiGroup = "shennong";
        private String apiName = "cancelOrder";
        private String apiId = "a6521c0ddd211bff699de0a36b507a31";

        private long? sellerId;
        private String tradeId;
        private String cancelMsg;

        public long? getSellerId() {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId) {
            this.sellerId = sellerId;
        }

        public String getTradeId() {
            return tradeId;
        }

        public void setTradeId(String tradeId) {
            this.tradeId = tradeId;
        }

        public String getCancelMsg() {
            return cancelMsg;
        }

        public void setCancelMsg(String cancelMsg) {
            this.cancelMsg = cancelMsg;
        }



        public IList getData(){
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(tradeId);
            list.Add(cancelMsg);
            return list;
        }
        public String getApiId(){
            return this.apiId;
        }
        public String getApiName(){
            return this.apiName;
        }
        public String getApiGroup(){
            return this.apiGroup;
        }

        public Type getClassName(){
            return typeof(CancelOrderResult);
        }

    }
}