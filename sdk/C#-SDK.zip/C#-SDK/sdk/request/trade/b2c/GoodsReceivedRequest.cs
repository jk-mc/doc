using System;
using resultAll;
using System.Collections;

namespace requestAll
{


    class GoodsReceivedRequest : IRequest<GoodsReceivedResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "goodsReceived";
        private String apiId = "aefd06deced038af6332084b5d1fbb99";

        private long? sellerId;
        private String tradeId;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getTradeId()
        {
            return tradeId;
        }

        public void setTradeId(String tradeId)
        {
            this.tradeId = tradeId;
        }



        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(tradeId);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(GoodsReceivedResult);
        }

    }
}