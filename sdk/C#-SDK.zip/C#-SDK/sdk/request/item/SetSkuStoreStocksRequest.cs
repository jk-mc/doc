using System;
using System.Collections.Generic;
using System.Collections;

using queryAll;
using resultAll;


namespace requestAll
{


    class SetSkuStoreStocksRequest : IRequest<SetSkuStoreStocksResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "setSkuStoreStocks";
        private String apiId = "d5e2266a5491e613ec0ebcab4808f8dd";

        private long? sellerId;
        private long? storeId;
        private String storeOuterId;
        private IList<SkuStoreStockParam> skuStoreStockList;


        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public long? getStoreId()
        {
            return storeId;
        }

        public void setStoreId(long? storeId)
        {
            this.storeId = storeId;
        }

        public String getStoreOuterId()
        {
            return storeOuterId;
        }

        public void setStoreOuterId(String storeOuterId)
        {
            this.storeOuterId = storeOuterId;
        }

        public IList<SkuStoreStockParam> getSkuStoreStockList()
        {
            return skuStoreStockList;
        }

        public void setSkuStoreStockList(IList<SkuStoreStockParam> skuStoreStockList)
        {
            this.skuStoreStockList = skuStoreStockList;
        }



        public IList getData()
        {
            IList list = new ArrayList();
           
            SetSkuStoreStocksParam param = new SetSkuStoreStocksParam();
            param.setSellerId(sellerId);
            param.setStoreId(storeId);
            param.setStoreOuterId(storeOuterId);
            param.setSkuStoreStockList(skuStoreStockList);
            list.Add(param);

            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(SetSkuStoreStocksResult);
        }

    }
}