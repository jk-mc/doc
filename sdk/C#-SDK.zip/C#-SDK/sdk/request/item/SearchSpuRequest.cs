using System;
using System.Collections;

using resultAll;

namespace requestAll
{


    class SearchSpuRequest : IRequest<SearchSpuResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "searchSpu";
        private String apiId = "5f68bbbc62bbd22b2bae6e307e056746";

        private long? sellerId;
        private String title;
        private long? categoryId;
        private int? status;
        private int? pageNo;
        private int? pageSize;

        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getTitle()
        {
            return title;
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public long? getCategoryId()
        {
            return categoryId;
        }

        public void setCategoryId(long? categoryId)
        {
            this.categoryId = categoryId;
        }

        public int? getStatus()
        {
            return status;
        }

        public void setStatus(int? status)
        {
            this.status = status;
        }

        public int? getPageNo()
        {
            return pageNo;
        }

        public void setPageNo(int? pageNo)
        {
            this.pageNo = pageNo;
        }

        public int? getPageSize()
        {
            return pageSize;
        }

        public void setPageSize(int? pageSize)
        {
            this.pageSize = pageSize;
        }

        



        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(title);
            list.Add(categoryId);
            list.Add(status);
            list.Add(pageNo);
            list.Add(pageSize);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(SearchSpuResult);
        }

    }
}