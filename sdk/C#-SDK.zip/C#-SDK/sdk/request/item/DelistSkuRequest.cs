using System;
using System.Collections;

using queryAll;
using resultAll;


namespace requestAll
{


    class DelistSkuRequest : IRequest<DelistSkuResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "delistSku";
        private String apiId = "de923710d7abda5083a361f8b11ed7b2";

        private long? sellerId;
        private long? skuId;


        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public long? getSkuId()
        {
            return skuId;
        }

        public void setSkuId(long? skuId)
        {
            this.skuId = skuId;
        }






        public IList getData()
        {
            IList list = new ArrayList();
            DelistSkuParam param = new DelistSkuParam();
            param.setSellerId(sellerId);
            param.setSkuId(skuId);
            

            list.Add(param);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(DelistSkuResult);
        }

    }
}