using System;
using System.Collections;

using resultAll;


namespace requestAll
{


    class ConfirmDeliveredRefundRequest : IRequest<ConfirmDeliveredRefundResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "confirmDeliveredRefund";
        private String apiId = "2ca79a2fcb89fab1d6442d7a0e6971b1";

        private long sellerId;
        private String refundId;
        
        public long getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getRefundId() {
            return refundId;
        }

        public void setRefundId(String refundId) {
            this.refundId = refundId;
        }


        public IList getData()
        {
           IList list = new ArrayList();
            
            String json = "{\"sellerId\":"+sellerId+ ",\"refundId\":\""+refundId+"\"}";
            list.Add(json);

            return list;
        }

        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(ConfirmDeliveredRefundResult);
        }

    }
}