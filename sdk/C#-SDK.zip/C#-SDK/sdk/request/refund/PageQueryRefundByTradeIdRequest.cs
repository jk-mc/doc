using System;
using System.Collections;

using queryAll;
using resultAll;

namespace requestAll
{


    class PageQueryRefundByTradeIdRequest : IRequest<PageQueryRefundByTradeIdResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "pageQueryRefundByTradeId";
        private String apiId = "48ec948ba840b00a5bab47ceaa37a078";

        private long sellerId;
        private String tradeId;
        private int pageNo;
        private int pageSize;

        public long getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long sellerId)
        {
            this.sellerId = sellerId;
        }


        public String getTradeId()
        {
            return this.tradeId;
        }

        public void setTradeId(String tradeId)
        {
            this.tradeId = tradeId;
        }

    
        public int getPageNo()
        {
            return this.pageNo;
        }

        public void setPageNo(int pageNo)
        {
            this.pageNo = pageNo;
        }


        public int getPageSize()
        {
            return this.pageSize;
        }

        public void setPageSize(int pageSize)
        {
            this.pageSize = pageSize;
        }

        public IList getData()
        {
            IList list = new ArrayList();

            PageQueryRefundByTradeIdParam param = new PageQueryRefundByTradeIdParam();
            param.setSellerId(sellerId);
            param.setTradeId(tradeId);
            param.setPageNo(pageNo);
            param.setPageSize(pageSize);
            list.Add(param);
            
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(PageQueryRefundByTradeIdResult);
        }

    }
}