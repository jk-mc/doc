using System;
using System.Collections;

using resultAll;

namespace requestAll
{


    class UpdateStoreBusinessHoursRequest : IRequest<UpdateStoreBusinessHoursResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "updateStoreBusinessHours";
        private String apiId = "d435183c7d7f01f03e9bd74875883e7a";

        private long? sellerId;
        private String storeReferId;
        private String openTime;
        private String closeTime;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getStoreReferId()
        {
            return storeReferId;
        }

        public void setStoreReferId(String storeReferId)
        {
            this.storeReferId = storeReferId;
        }

        public String getOpenTime()
        {
            return openTime;
        }

        public void setOpenTime(String openTime)
        {
            this.openTime = openTime;
        }

        public String getCloseTime()
        {
            return closeTime;
        }

        public void setCloseTime(String closeTime)
        {
            this.closeTime = closeTime;
        }



        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(storeReferId);
            list.Add(openTime);
            list.Add(closeTime);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(UpdateStoreBusinessHoursResult);
        }

    }
}