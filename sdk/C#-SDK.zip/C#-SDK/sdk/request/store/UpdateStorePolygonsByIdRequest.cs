using System;
using System.Collections;

using resultAll;

namespace requestAll
{


    class UpdateStorePolygonsByIdRequest : IRequest<UpdateStorePolygonsByIdResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "updateStorePolygonsById";
        private String apiId = "c86b25cd0be64a16fab6287b2d7be7b8";

        private long? sellerId;
        private String storeReferId;
        private String polygons;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getStoreReferId()
        {
            return storeReferId;
        }

        public void setStoreReferId(String storeReferId)
        {
            this.storeReferId = storeReferId;
        }

        public String getPolygons()
        {
            return polygons;
        }

        public void setPolygons(String polygons)
        {
            this.polygons = polygons;
        }



        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(storeReferId);
            list.Add(polygons);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(UpdateStorePolygonsByIdResult);
        }

    }
}