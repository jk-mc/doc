using System;

namespace resultAll
{
    [Serializable]
    class AcceptRefundResult : BaseResult 
    {
        public AcceptRefundResult()
        {
        }
        public AcceptRefundResult(int? code, String msg) : base(code, msg) { }


    }



}