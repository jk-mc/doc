using System;

namespace resultAll
{
    [Serializable]
    class UpdateStoreBusinessHoursResult : BaseResult
    {
        public UpdateStoreBusinessHoursResult()
        {
        }
        public UpdateStoreBusinessHoursResult(int code, String msg) : base(code, msg) { }

    }



}