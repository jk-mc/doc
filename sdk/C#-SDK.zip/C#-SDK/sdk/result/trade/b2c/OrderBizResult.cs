using System;
using System.Collections.Generic;

namespace resultAll
{
    [Serializable]
    class OrderBizResult
    {
         /**
         * pajk订单号
         */
        private String bizOrderId;
        /**
         * pajk店铺ID(B2C业务请忽略)
         */
        private long? storeId;
        /**
         *  pajk商家ID
         */
        private long? sellerId;

        /**
         * 买商品数量
         */
        private long? buyAmount;

        /**
         * 是否有处方药(1代表有处方药)
         */
        private int? isPrescribed;

        /**
         * 渠道号
         */
        private String channel;

        /**
         * ֧支付时间
         */
        private long? payTime;

        /**
         * 用户实际支付现金
         */
        private long? actualTotalFee;

        /**
         * ֧支付方式
         */
        private int? payMode;

        /**
         * 订单状态
         */
        private String storeOrderStatus;

        /**
         * "普通订单" : "1"
        * "未审核处方药订单" : "2"
        * "已审核通过处方药订单" : "3"
        * "已审核未通过处方药订单" : "4"
         */
        private String storeOrderType;

        /**
         * 买家id
         * */
        private long? buyerId;

        /**
         * 订单创建时间 单位为秒 时间戳
         */
        private long? createTime;

        /**
         * 最后修改时间 单位秒 UTC 时间戳
         */
        private long? modifyTime;

        /**
         * 下单平台（中文描述）
         */
        private String platform;

        /**
         * 下单渠道
         */
        private String subBizType;

        /**
         * 商品信息
         */
        private IList<OrderItemResult> items;


        public String getBizOrderId()
        {
            return bizOrderId;
        }

        public void setBizOrderId(String bizOrderId)
        {
            this.bizOrderId = bizOrderId;
        }

        public long? getStoreId()
        {
            return storeId;
        }

        public void setStoreId(long? storeId)
        {
            this.storeId = storeId;
        }

        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public long? getBuyAmount()
        {
            return buyAmount;
        }

        public void setBuyAmount(long? buyAmount)
        {
            this.buyAmount = buyAmount;
        }

        public int? getIsPrescribed()
        {
            return isPrescribed;
        }

        public void setIsPrescribed(int? isPrescribed)
        {
            this.isPrescribed = isPrescribed;
        }

        public String getChannel()
        {
            return channel;
        }

        public void setChannel(String channel)
        {
            this.channel = channel;
        }

        public long? getPayTime()
        {
            return payTime;
        }

        public void setPayTime(long? payTime)
        {
            this.payTime = payTime;
        }

        public long? getActualTotalFee()
        {
            return actualTotalFee;
        }

        public void setActualTotalFee(long? actualTotalFee)
        {
            this.actualTotalFee = actualTotalFee;
        }

        public int? getPayMode()
        {
            return payMode;
        }

        public void setPayMode(int? payMode)
        {
            this.payMode = payMode;
        }

        public String getStoreOrderStatus()
        {
            return storeOrderStatus;
        }

        public void setStoreOrderStatus(String storeOrderStatus)
        {
            this.storeOrderStatus = storeOrderStatus;
        }

        public String getStoreOrderType()
        {
            return storeOrderType;
        }

        public void setStoreOrderType(String storeOrderType)
        {
            this.storeOrderType = storeOrderType;
        }

        public long? getBuyerId()
        {
            return buyerId;
        }

        public void setBuyerId(long? buyerId)
        {
            this.buyerId = buyerId;
        }

        public long? getCreateTime()
        {
            return createTime;
        }

        public void setCreateTime(long? createTime)
        {
            this.createTime = createTime;
        }

        public long? getModifyTime()
        {
            return modifyTime;
        }

        public void setModifyTime(long? modifyTime)
        {
            this.modifyTime = modifyTime;
        }

        public String getPlatform()
        {
            return platform;
        }

        public void setPlatform(String platform)
        {
            this.platform = platform;
        }

        public String getSubBizType()
        {
            return subBizType;
        }

        public void setSubBizType(String subBizType)
        {
            this.subBizType = subBizType;
        }

        public IList<OrderItemResult> getItems()
        {
            return items;
        }

        public void setItems(IList<OrderItemResult> items)
        {
            this.items = items;
        }


    }


}