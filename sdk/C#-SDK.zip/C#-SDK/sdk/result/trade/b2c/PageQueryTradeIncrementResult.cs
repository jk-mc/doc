using System;
using System.Collections.Generic;

namespace resultAll
{
    [Serializable]
    class PageQueryTradeIncrementResult : PageResult 
    {
        public PageQueryTradeIncrementResult()
        {
        }
        public PageQueryTradeIncrementResult(int? code, String msg) : base(code, msg) { }


        private IList<TradeResult> model;


        public IList<TradeResult> getModel()
        {
            return model;
        }

        public void setModel(IList<TradeResult> model)
        {
            this.model = model;
        }


    }



}