using System;

namespace resultAll
{
    [Serializable]
    class QueryTradeDetailResult : BaseResult
    {
        public QueryTradeDetailResult()
        {
        }
        public QueryTradeDetailResult(int code, String msg) : base(code, msg) { }


        private TradeDetailResult model;


        public TradeDetailResult getModel()
        {
            return model;
        }

        public void setModel(TradeDetailResult model)
        {
            this.model = model;
        }

    }



}