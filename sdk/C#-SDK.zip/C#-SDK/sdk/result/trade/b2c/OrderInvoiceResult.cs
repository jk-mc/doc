using System;

namespace resultAll
{
    [Serializable]
    class OrderInvoiceResult
    {
        /**
       * 发票类型 1.普通发票, 2.增值税发票, 0.没有发票
       */
        private int? invoiceTypeId = 0;

        /**
         * 发票抬头
         */
        private String invoiceTitle;

        public int? getInvoiceTypeId()
        {
            return invoiceTypeId;
        }

        public void setInvoiceTypeId(int? invoiceTypeId)
        {
            this.invoiceTypeId = invoiceTypeId;
        }

        public String getInvoiceTitle()
        {
            return invoiceTitle;
        }

        public void setInvoiceTitle(String invoiceTitle)
        {
            this.invoiceTitle = invoiceTitle;
        }






    }


}