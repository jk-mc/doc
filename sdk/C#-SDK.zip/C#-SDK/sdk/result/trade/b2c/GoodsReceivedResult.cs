using System;

namespace resultAll
{
    [Serializable]
    class GoodsReceivedResult : BaseResult
    {
        public GoodsReceivedResult()
        {
        }
        public GoodsReceivedResult(int code, String msg) : base(code, msg) { }

    }



}