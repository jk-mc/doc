using System;

namespace resultAll
{
    [Serializable]
    class CarrierResult
    {
        private long? carrierId;
        private String carrierNick;

        public long? getCarrierId() {
            return this.carrierId;
        }

        public void setCarrierId(long? carrierId)
        {
            this.carrierId = carrierId;
        }

        public String getCarrierNick()
        {
            return this.carrierNick;
        }

        public void setCarrierNick(String carrierNick)
        {
           this.carrierNick = carrierNick;
        }


    }


}