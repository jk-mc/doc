using System;

namespace resultAll
{
    [Serializable]
    class SingleQueryOrderResult : BaseResult
    {
        public SingleQueryOrderResult()
        {
        }
        public SingleQueryOrderResult(int code, String msg) : base(code, msg) { }


        private TradeFullResult model;


        public TradeFullResult getModel()
        {
            return model;
        }

        public void setModel(TradeFullResult model)
        {
            this.model = model;
        }

    }



}