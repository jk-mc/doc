using System;

namespace resultAll
{
    [Serializable]
    class OrderItemResult
    {
        /**
         * pajk商品ID
         */
        private long? itemId;
        /**
         * pajk商品skuID
         */
        private long? itemSkuId;
        /**
         * 购买数量
         */
        private long? buyAmount;

        /**
         * 合作方商品ID
         */
        private String referId;

        /**
         * 是否处方药(1代表有处方药, 0代表没有处方药)
         */
        private int? isPrescribed = 0;
        /**
         * 商品名
         */
        private String itemName;
        /**
         * 实际价格,销售价格,单位分
         */
        private long? actualPrice;

        /**
         * 结算价格(默认为0,代表没有结算价格)
         */
        private long? settlementPrice;

        /**
         * 返点比例(0~100, 小数点后最多1位)
         */
        private String rebateRatio;

        /**
         * �˿���Ʒ����
         */
        private int? refundCnt;

        public long? getItemId()
        {
            return itemId;
        }

        public void setItemId(long? itemId)
        {
            this.itemId = itemId;
        }

        public long? getItemSkuId()
        {
            return itemSkuId;
        }

        public void setItemSkuId(long? itemSkuId)
        {
            this.itemSkuId = itemSkuId;
        }

        public long? getBuyAmount()
        {
            return buyAmount;
        }

        public void setBuyAmount(long? buyAmount)
        {
            this.buyAmount = buyAmount;
        }

        public String getReferId()
        {
            return referId;
        }

        public void setReferId(String referId)
        {
            this.referId = referId;
        }

        public int? getIsPrescribed()
        {
            return isPrescribed;
        }

        public void setIsPrescribed(int? isPrescribed)
        {
            this.isPrescribed = isPrescribed;
        }

        public String getItemName()
        {
            return itemName;
        }

        public void setItemName(String itemName)
        {
            this.itemName = itemName;
        }

        public long? getActualPrice()
        {
            return actualPrice;
        }

        public void setActualPrice(long? actualPrice)
        {
            this.actualPrice = actualPrice;
        }

        public long? getSettlementPrice()
        {
            return settlementPrice;
        }

        public void setSettlementPrice(long? settlementPrice)
        {
            this.settlementPrice = settlementPrice;
        }

        public String getRebateRatio()
        {
            return rebateRatio;
        }

        public void setRebateRatio(String rebateRatio)
        {
            this.rebateRatio = rebateRatio;
        }

        public int? getRefundCnt()
        {
            return refundCnt;
        }

        public void setRefundCnt(int? refundCnt)
        {
            this.refundCnt = refundCnt;
        }


    }


}