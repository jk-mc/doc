using System;

namespace resultAll
{
    [Serializable]
    class QuerySkuByIdResult : BaseResult
    {
        public QuerySkuByIdResult()
        {
        }
        public QuerySkuByIdResult(int code, String msg) : base(code, msg) { }

        private ItemSkuResult model;

        public ItemSkuResult getModel()
        {
            return model;
        }

        public void setModel(ItemSkuResult model)
        {
            this.model = model;
        }


    }



}