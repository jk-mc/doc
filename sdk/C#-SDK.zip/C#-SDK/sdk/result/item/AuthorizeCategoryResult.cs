using System;

namespace resultAll
{
    [Serializable]
    class AuthorizeCategoryResult 
    {
        private long? categoryId;
        private String categoryName;
        private String isCspu;


        public long? getCategoryId()
        {
            return categoryId;
        }

        public void setCategoryId(long? categoryId)
        {
            this.categoryId = categoryId;
        }

        public String getCategoryName()
        {
            return categoryName;
        }

        public void setCategoryName(String categoryName)
        {
            this.categoryName = categoryName;
        }

        public String getIsCspu()
        {
            return isCspu;
        }

        public void setIsCspu(String isCspu)
        {
            this.isCspu = isCspu;
        }

    }



}