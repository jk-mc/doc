using System;

namespace resultAll
{
    [Serializable]
    class DelistSkuResult : BaseResult
    {
        public DelistSkuResult()
        {
        }
        public DelistSkuResult(int code, String msg) : base(code, msg) { }

    }



}