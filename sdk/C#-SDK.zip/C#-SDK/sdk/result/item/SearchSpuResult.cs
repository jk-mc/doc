using System;
using System.Collections.Generic;

namespace resultAll
{
    [Serializable]
    class SearchSpuResult : PageResult
    {
        public SearchSpuResult()
        {
        }
        public SearchSpuResult(int code, String msg) : base(code, msg) { }


        private IList<ItemSearchSpuResult> model;


        public IList<ItemSearchSpuResult> getModel()
        {
            return model;
        }

        public void setModel(IList<ItemSearchSpuResult> model)
        {
            this.model = model;
        }


    }



}