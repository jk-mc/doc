using System;

namespace resultAll
{
    [Serializable]
    class SkuStoreStockResult
    {
        private long? skuId;
        /**
         * 可销售库存
         */
        private int? stockNum;

        /**
         * 总库存
         */
        private int? totalStockNum;
        /**
         * 冻结库存 = 总库存 - 可销售库存
         */
        private int? frozenStockNum;


        public long? getSkuId()
        {
            return skuId;
        }

        public void setSkuId(long? skuId)
        {
            this.skuId = skuId;
        }

        public int? getStockNum()
        {
            return stockNum;
        }

        public void setStockNum(int? stockNum)
        {
            this.stockNum = stockNum;
        }

        public int? getTotalStockNum()
        {
            return totalStockNum;
        }

        public void setTotalStockNum(int? totalStockNum)
        {
            this.totalStockNum = totalStockNum;
        }

        public int? getFrozenStockNum()
        {
            return frozenStockNum;
        }

        public void setFrozenStockNum(int? frozenStockNum)
        {
            this.frozenStockNum = frozenStockNum;
        }


    }


}