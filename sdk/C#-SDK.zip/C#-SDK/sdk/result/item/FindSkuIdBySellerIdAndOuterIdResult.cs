using System;
using System.Collections.Generic;

namespace resultAll
{
    [Serializable]
    class FindSkuIdBySellerIdAndOuterIdResult : BaseResult
    {
        public FindSkuIdBySellerIdAndOuterIdResult()
        {
        }
        public FindSkuIdBySellerIdAndOuterIdResult(int code, String msg) : base(code, msg) { }

        private IList<ItemSkuSimpleResult> model;

        public IList<ItemSkuSimpleResult> getModel()
        {
            return model;
        }

        public void setModel(IList<ItemSkuSimpleResult> model)
        {
            this.model = model;
        }


    }



}