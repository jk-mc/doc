using System;

namespace resultAll
{
    [Serializable]
    class SetSkuStoreStocksResult : BaseResult
    {
        public SetSkuStoreStocksResult()
        {
        }
        public SetSkuStoreStocksResult(int code, String msg) : base(code, msg) { }

    }



}