using System;

namespace resultAll
{
    [Serializable]
    class QuerySpuByIdResult : BaseResult
    {
        public QuerySpuByIdResult()
        {
        }
        public QuerySpuByIdResult(int code, String msg) : base(code, msg) { }

        private ItemSpuResult model;

        public ItemSpuResult getModel()
        {
            return model;
        }

        public void setModel(ItemSpuResult model)
        {
            this.model = model;
        }


    }



}