using System;

namespace resultAll
{
    [Serializable]
    class ListSkuResult : BaseResult
    {
        public ListSkuResult()
        {
        }
        public ListSkuResult(int code, String msg) : base(code, msg) { }

    }



}