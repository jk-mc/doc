using System;

namespace resultAll
{
    [Serializable]
    class SetSkuStorePricesResult : BaseResult
    {
        public SetSkuStorePricesResult()
        {
        }
        public SetSkuStorePricesResult(int code, String msg) : base(code, msg) { }

    }



}