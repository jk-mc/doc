using System;


namespace resultAll 
{
    [Serializable]
    class BaseResult {
        
        private int? resultCode;
        private string resultMsg;

         public BaseResult(){
            this.resultCode = 0;
            this.resultMsg = "成功";
        }

        public BaseResult(int? code, String msg) {
            this.resultCode = code;
            this.resultMsg = msg;
            
        }


        public void setResultCode(int? resultCode){
            this.resultCode = resultCode;

        }

        public int? getResultCode(){
            return this.resultCode;
        }


        public void setResultMsg(string resultMsg){
            this.resultMsg = resultMsg;
        }

        public string getResultMsg(){
            return this.resultMsg;
        }

        public bool isSuccess(){
            return 0 == resultCode;
        }

    }

    

}