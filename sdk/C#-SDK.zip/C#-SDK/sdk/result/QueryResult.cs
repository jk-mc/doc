using System;

namespace resultAll 
{
    [Serializable]
     class QueryResult : BaseResult {
        private String model;
        
        public String getModel() {
            return model;
        }

        public void setModel(String model) {
            this.model = model;
        }

        public QueryResult(int code, String msg) : base(code, msg){}

        public QueryResult(){}


    }

    


}