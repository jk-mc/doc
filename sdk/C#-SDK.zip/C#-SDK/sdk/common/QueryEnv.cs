using System;


namespace commonUtil {
    
    static class QueryEnv{

            
        static string DEV = "LATEST";
        static string TEST = "TEST";
        static string PROD = "PROD";

        static string DEV_URL ="https://openapi.dev.pajk.cn/api/v1/";
        static string TEST_URL = "https://openapi.test.pajk.cn/api/v1/";
        static string PROD_URL = "https://openapi.jk.cn/api/v1/";
        

        public static ENV getDev(){
            return new ENV(DEV,DEV_URL);
        }

        public static ENV getTest(){
            return new ENV(TEST,TEST_URL);
        }

        public static ENV getProd(){
            return new ENV(PROD,PROD_URL);
        }
    }

    public class ENV{
        private string env;
        private string url;

        public ENV(string env, string url){
            this.url = url;
            this.env = env;
        }

        public string getEnv(){
            return this.env;
        }
        public void setEnv(string env){
            this.env = env;
        }

        public string getUrl(){
            return this.url;
        }
        public void setUrl(string url){
            this.url = url;
        }
    }


}