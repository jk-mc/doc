using System;

namespace queryAll
{
    [Serializable]
    class SkuStorePriceParam
    {
        
        private long? skuId;
        private long? price;

        public long? getSkuId()
        {
            return this.skuId;
        }

        public void setSkuId(long? skuId)
        {
            this.skuId = skuId;
        }

        public long? getPrice()
        {
            return this.price;
        }

        public void setPrice(long? price)
        {
            this.price = price;
        }

    }


}