using System;
using System.Collections.Generic;


namespace queryAll
{
    [Serializable]
    class PageQueryRefundParam
    {
        private long? sellerId;
        private String startTime;
        private String endTime;
        private String status;
        private int? pageNo;
        private int? pageSize;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getStartTime()
        {
            return this.startTime;
        }

        public void setStartTime(String startTime)
        {
            this.startTime = startTime;
        }

        public String getEndTime()
        {
            return this.endTime;
        }

        public void setEndTime(String endTime)
        {
            this.endTime = endTime;
        }


        public String getStatus()
        {
            return this.status;
        }

        public void setStatus(String status)
        {
            this.status = status;
        }

    
        public int? getPageNo()
        {
            return this.pageNo;
        }

        public void setPageNo(int? pageNo)
        {
            this.pageNo = pageNo;
        }


        public int? getPageSize()
        {
            return this.pageSize;
        }

        public void setPageSize(int? pageSize)
        {
            this.pageSize = pageSize;
        }




    }


}