<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 17:08
 */

include "Autoloader.php";

$key = "d2d03a99b8227686aaa7d47a4535419a";
$partnerId = "yaofang_test_03";


$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new SearchSpuRequest();
$request->setSellerId("989810607"); //sellerId pajk的卖家id 类型为long
$request->setTitle("牙刷"); //title 商品名称 如果不需要该值纳入搜索则传入"*"
$request->setCategoryId(0); //分类  如果不需要该值纳入搜索  则传入0L
$request->setStatus(0); // 状态  此版本只支持传入状态为0
$request->setPageNo(1); //当前页码 最小值为1
$request->setPageSize(10); // 每页显示数量
$result =$client->execute($request);
var_dump($result);