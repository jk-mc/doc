<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/30
 * Time: 16:54
 */


include "Autoloader.php";

$key = "0031ae2efaacd0fe644580de630f9d13";
$partnerId = "yaofang_test_01";


$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new UpdateStoreBusinessHoursRequest();
$request->setSellerId("2523760705");
$request->setStoreReferId("QMY0001123123");
$request->setOpenTime("09:01");
$request->setCloseTime("20:50");
$result =$client->execute($request);
var_dump($result);
