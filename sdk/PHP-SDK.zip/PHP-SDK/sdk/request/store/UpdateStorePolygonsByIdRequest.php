<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/30
 * Time: 16:51
 */

class UpdateStorePolygonsByIdRequest
{
    private $apiGroup = "shennong";
    private $apiName = "updateStorePolygonsById";
    private $apiId = "c86b25cd0be64a16fab6287b2d7be7b8";

    private $sellerId;
    private $storeReferId;
    private $polygons;



    public function getData(){
        return array(
            "arg1"=>$this->sellerId,
            'arg2'=>$this->storeReferId,
            'arg3'=>$this->polygons,
        );
    }

    /**
     * @return mixed
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @return mixed
     */
    public function getStoreReferId()
    {
        return $this->storeReferId;
    }

    /**
     * @param mixed $storeReferId
     */
    public function setStoreReferId($storeReferId)
    {
        $this->storeReferId = $storeReferId;
    }

    /**
     * @return mixed
     */
    public function getPolygons()
    {
        return $this->polygons;
    }

    /**
     * @param mixed $polygons
     */
    public function setPolygons($polygons)
    {
        $this->polygons = $polygons;
    }



    /**
     * @return string
     */
    public function getApiGroup()
    {
        return $this->apiGroup;
    }

    /**
     * @return string
     */
    public function getApiName()
    {
        return $this->apiName;
    }

    /**
     * @return string
     */
    public function getApiId()
    {
        return $this->apiId;
    }



}