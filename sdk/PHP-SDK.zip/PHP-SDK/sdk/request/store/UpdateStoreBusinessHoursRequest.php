<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/30
 * Time: 16:45
 */

class UpdateStoreBusinessHoursRequest
{

    private $apiGroup = "shennong";
    private $apiName = "updateStoreBusinessHours";
    private $apiId = "d435183c7d7f01f03e9bd74875883e7a";

    private $sellerId;
    private $storeReferId;
    private $openTime;
    private $closeTime;


    public function getData(){
        return array(
            "arg1"=>$this->sellerId,
            'arg2'=>$this->storeReferId,
            'arg3'=>$this->openTime,
            'arg4'=>$this->closeTime,
        );
    }

    /**
     * @return mixed
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @return mixed
     */
    public function getStoreReferId()
    {
        return $this->storeReferId;
    }

    /**
     * @param mixed $storeReferId
     */
    public function setStoreReferId($storeReferId)
    {
        $this->storeReferId = $storeReferId;
    }

    /**
     * @return mixed
     */
    public function getOpenTime()
    {
        return $this->openTime;
    }

    /**
     * @param mixed $openTime
     */
    public function setOpenTime($openTime)
    {
        $this->openTime = $openTime;
    }

    /**
     * @return mixed
     */
    public function getCloseTime()
    {
        return $this->closeTime;
    }

    /**
     * @param mixed $closeTime
     */
    public function setCloseTime($closeTime)
    {
        $this->closeTime = $closeTime;
    }

    /**
     * @return string
     */
    public function getApiGroup()
    {
        return $this->apiGroup;
    }

    /**
     * @return string
     */
    public function getApiName()
    {
        return $this->apiName;
    }

    /**
     * @return string
     */
    public function getApiId()
    {
        return $this->apiId;
    }


}