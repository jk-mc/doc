<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/30
 * Time: 16:49
 */

class UpdateStoreStatusRequest
{
    private $apiGroup = "shennong";
    private $apiName = "updateStoreStatus";
    private $apiId = "1576d7892ccb7833bd6f45690b031431";


    private $sellerId;
    private $storeReferId;
    private $status;


    public function getData(){
        return array(
            "arg1"=>$this->sellerId,
            'arg2'=>$this->storeReferId,
            'arg3'=>$this->status,

        );
    }

    /**
     * @return mixed
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @return mixed
     */
    public function getStoreReferId()
    {
        return $this->storeReferId;
    }

    /**
     * @param mixed $storeReferId
     */
    public function setStoreReferId($storeReferId)
    {
        $this->storeReferId = $storeReferId;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }




    /**
     * @return string
     */
    public function getApiGroup()
    {
        return $this->apiGroup;
    }

    /**
     * @return string
     */
    public function getApiName()
    {
        return $this->apiName;
    }

    /**
     * @return string
     */
    public function getApiId()
    {
        return $this->apiId;
    }



}