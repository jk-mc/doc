<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 13:41
 *
 * @deprecated  该方法已经被 @link QueryTradeDetailRequest 代替, 请尽快切换使用新方法.
 */

class SingleQueryOrderRequest implements IRequest
{

    private $apiGroup = "shennong";
    private $apiName = "querySingleB2COrderForOpenApi";
    private $apiId = "0a296dafe841090172ee80af2307087c";


    private $sellerId;
    private $tradeId;


    public function getData(){
        return array(
            "arg1"=>$this->sellerId,
            'arg2'=>$this->tradeId
        );
    }

    public function setSellerId($sellerId){
        $this->sellerId = $sellerId;
    }

    public function setTradeId($tradeId){
        $this->tradeId = $tradeId;
    }



    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}