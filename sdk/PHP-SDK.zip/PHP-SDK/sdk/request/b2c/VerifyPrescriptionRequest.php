<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 16:19
 */

class VerifyPrescriptionRequest
{

    private $apiGroup = "shennong";
    private $apiName = "verifyPrescription";
    private $apiId = "4853b5e0bac42eab185338dccdf38f18";


    private $sellerId;
    private $tradeId;
    private $verifyStatus;
    private $verifyMsg;


    public function getData(){
        return array(
            "arg1"=>$this->sellerId,
            'arg2'=>$this->tradeId,
            'arg3'=>$this->verifyStatus,
            'arg4'=>$this->verifyMsg
        );
    }




    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $tradeId
     */
    public function setTradeId($tradeId)
    {
        $this->tradeId = $tradeId;
    }

    /**
     * @param mixed $verifyStatus
     */
    public function setVerifyStatus($verifyStatus)
    {
        $this->verifyStatus = $verifyStatus;
    }

    /**
     * @param mixed $verifyMsg
     */
    public function setVerifyMsg($verifyMsg)
    {
        $this->verifyMsg = $verifyMsg;
    }



    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}