<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/27
 * Time: 15:30
 */

class BatchQueryB2CCarrierRequest implements IRequest
{
    private $apiGroup = "shennong";
    private $apiName = "batchQueryB2CCarrier";
    private $apiId = "2810e9c32c2174278ea5920c35608873";




    public function getData(){
        return array();
    }

    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}