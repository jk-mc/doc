<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 13:54
 */

class UpdateEmsRequest implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "updateEMS";
    private $apiId = "9d923900e2c909c387efb586090441ad";


    private $sellerId;
    private $tradeId;
    private $carrierId ;
    private $trackingNumber  ;
    private $operator = "system";



    public function getData(){
        return array(
            'arg1'=> $this->sellerId,
            'arg2'=> $this->tradeId,
            'arg3'=> $this->carrierId,
            'arg4'=> $this->trackingNumber,
            'arg5'=> $this->operator
            );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $tradeId
     */
    public function setTradeId($tradeId)
    {
        $this->tradeId = $tradeId;
    }

    /**
     * @param mixed $carrierId
     */
    public function setCarrierId($carrierId)
    {
        $this->carrierId = $carrierId;
    }

    /**
     * @param mixed $trackingNumber
     */
    public function setTrackingNumber($trackingNumber)
    {
        $this->trackingNumber = $trackingNumber;
    }

    /**
     * @param string $operator
     */
    public function setOperator($operator)
    {
        $this->operator = $operator;
    }







    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}