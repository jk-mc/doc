<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/29
 * Time: 16:12
 */

class QueryTradeDetailRequest implements IRequest
{
    private $apiGroup = "shennong";
    private $apiName = "queryTradeDetail";
    private $apiId = "d2d3eb1f3286bd2a9f1d9b77aa35d3b3";

    private $sellerId;
    private $tradeId;


    public function getData(){
        $arr = array(
            "sellerId" => $this->sellerId,
            "tradeId" => $this->tradeId,
        );
        return array(
            'arg1' => json_encode($arr)
        );


    }

    /**
     * @return mixed
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @return mixed
     */
    public function getTradeId()
    {
        return $this->tradeId;
    }

    /**
     * @param mixed $tradeId
     */
    public function setTradeId($tradeId)
    {
        $this->tradeId = $tradeId;
    }






    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }

}