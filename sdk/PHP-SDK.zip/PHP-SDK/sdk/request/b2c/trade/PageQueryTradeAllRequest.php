<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/29
 * Time: 15:18
 */

class PageQueryTradeAllRequest implements IRequest
{
    private $apiGroup = "shennong";
    private $apiName = "pageQueryTradeAll";
    private $apiId = "fb5accf0552682d99d7f3583bcf24a3a";

    private $sellerId;
    private $startTime;
    private $endTime;
    private $status;
    private $pageNo;
    private $pageSize;


    public function getData(){
        $arr = array(
            "sellerId" => $this->sellerId,
            "startTime" => $this->startTime,
            "endTime" => $this->endTime,
            "status" => $this->status,
            "pageNo" => $this->pageNo,
            "pageSize" => $this->pageSize
        );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @return mixed
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @return mixed
     */
    public function getStartTime()
    {
        return $this->startTime;
    }

    /**
     * @param mixed $startTime
     */
    public function setStartTime($startTime)
    {
        $this->startTime = $startTime;
    }

    /**
     * @return mixed
     */
    public function getEndTime()
    {
        return $this->endTime;
    }

    /**
     * @param mixed $endTime
     */
    public function setEndTime($endTime)
    {
        $this->endTime = $endTime;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getPageNo()
    {
        return $this->pageNo;
    }

    /**
     * @param mixed $pageNo
     */
    public function setPageNo($pageNo)
    {
        $this->pageNo = $pageNo;
    }

    /**
     * @return mixed
     */
    public function getPageSize()
    {
        return $this->pageSize;
    }

    /**
     * @param mixed $pageSize
     */
    public function setPageSize($pageSize)
    {
        $this->pageSize = $pageSize;
    }



    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}