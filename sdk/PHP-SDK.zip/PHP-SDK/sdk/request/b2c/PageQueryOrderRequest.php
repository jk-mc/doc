<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 14:15
 * @deprecated 该方法已经被 trade/PageQueryTradeAll 和 trade/PageQueryTradeIncrementRequest 2个方法代替,
 * 请尽快切换到新方法上.
 */


class PageQueryOrderRequest implements IRequest
{

    private $apiGroup = "shennong";
    private $apiName = "pageQueryB2COrderForOpenApi";
    private $apiId = "e4e0475234a625f4f78ca7477296b396";


    private $sellerId;
    private $startTime;
    private $endTime;
    private $orderStatus;
    private $orderType;
    private $pageNo;
    private $pageSize;




    public function getData(){
        return array(
            "arg1"=>$this->sellerId,
            'arg2'=>$this->startTime,
            'arg3'=>$this->endTime,
            'arg4'=>$this->orderStatus,
            'arg5'=>$this->orderType,
            'arg6'=>$this->pageNo,
            'arg7'=>$this->pageSize
        );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $startTime
     */
    public function setStartTime($startTime)
    {
        $this->startTime = $startTime;
    }

    /**
     * @param mixed $endTime
     */
    public function setEndTime($endTime)
    {
        $this->endTime = $endTime;
    }

    /**
     * @param mixed $orderStatus
     */
    public function setOrderStatus($orderStatus)
    {
        $this->orderStatus = $orderStatus;
    }

    /**
     * @param mixed $orderType
     */
    public function setOrderType($orderType)
    {
        $this->orderType = $orderType;
    }

    /**
     * @param mixed $pageNo
     */
    public function setPageNo($pageNo)
    {
        $this->pageNo = $pageNo;
    }

    /**
     * @param mixed $pageSize
     */
    public function setPageSize($pageSize)
    {
        $this->pageSize = $pageSize;
    }




    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}