<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/29
 * Time: 20:05
 */

class AcceptRefundRequest implements IRequest
{
    private $apiGroup = "shennong";
    private $apiName = "acceptRefund";
    private $apiId = "034dfe681f145d4a0f7aa25e49167e22";

    private $sellerId;
    private $refundId;

    public function getData(){
        $arr = array(
            "sellerId" => $this->sellerId,
            "refundId" => $this->refundId,
        );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @return mixed
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @return mixed
     */
    public function getRefundId()
    {
        return $this->refundId;
    }

    /**
     * @param mixed $refundId
     */
    public function setRefundId($refundId)
    {
        $this->refundId = $refundId;
    }



    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}