<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/29
 * Time: 16:50
 */

class PageQueryRefundByTradeIdRequest implements IRequest
{
    private $apiGroup = "shennong";
    private $apiName = "pageQueryRefundByTradeId";
    private $apiId = "48ec948ba840b00a5bab47ceaa37a078";

    private $sellerId;
    private $tradeId;
    private $pageNo;
    private $pageSize;

    public function getData(){
        $arr = array(
            "sellerId" => $this->sellerId,
            "tradeId" => $this->tradeId,
            "pageNo" => $this->pageNo,
            "pageSize" => $this->pageSize
        );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @return mixed
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @return mixed
     */
    public function getTradeId()
    {
        return $this->tradeId;
    }

    /**
     * @param mixed $tradeId
     */
    public function setTradeId($tradeId)
    {
        $this->tradeId = $tradeId;
    }

    /**
     * @return mixed
     */
    public function getPageNo()
    {
        return $this->pageNo;
    }

    /**
     * @param mixed $pageNo
     */
    public function setPageNo($pageNo)
    {
        $this->pageNo = $pageNo;
    }

    /**
     * @return mixed
     */
    public function getPageSize()
    {
        return $this->pageSize;
    }

    /**
     * @param mixed $pageSize
     */
    public function setPageSize($pageSize)
    {
        $this->pageSize = $pageSize;
    }




    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}