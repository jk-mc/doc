<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/29
 * Time: 19:20
 * 拒绝退款
 * 平安外部合作方(商家)拒绝用户申请的退款
 */

class RejectRefundRequest implements IRequest
{
    private $apiGroup = "shennong";
    private $apiName = "rejectRefund";
    private $apiId = "ed31bc50c6896de1cfcbf1a652a4eb87";

    private $sellerId;
    private $refundId;
    private $reason;

    public function getData(){
        $arr = array(
            "sellerId" => $this->sellerId,
            "refundId" => $this->refundId,
            "reason"   => $this->reason
        );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @return mixed
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @return mixed
     */
    public function getRefundId()
    {
        return $this->refundId;
    }

    /**
     * @param mixed $refundId
     */
    public function setRefundId($refundId)
    {
        $this->refundId = $refundId;
    }

    /**
     * @return mixed
     */
    public function getReason()
    {
        return $this->reason;
    }

    /**
     * @param mixed $reason
     */
    public function setReason($reason)
    {
        $this->reason = $reason;
    }





    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}