<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/29
 * Time: 16:50
 */

class QueryRefundRequest implements IRequest
{
    private $apiGroup = "shennong";
    private $apiName = "queryRefund";
    private $apiId = "104071317ebac50060fa711b8374d7a0";

    private $sellerId;
    private $refundId;

    public function getData(){
        $arr = array(
            "sellerId" => $this->sellerId,
            "refundId" => $this->refundId,
        );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @return mixed
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @return mixed
     */
    public function getRefundId()
    {
        return $this->refundId;
    }

    /**
     * @param mixed $refundId
     */
    public function setRefundId($refundId)
    {
        $this->refundId = $refundId;
    }



    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}