<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/29
 * Time: 20:04
 * 受理退款单
 * 退货退款的场景 需要平安外部合作方(商家)先受理 受理需要传退货地址参数.
 */

class ReceivedRefundRequest implements IRequest
{
    private $apiGroup = "shennong";
    private $apiName = "receivedRefund";
    private $apiId = "44c284ba6d16a88bc8c195d20503b4ad";

    private $sellerId;
    private $refundId;

    private $prov;
    private $city;
    private $area;
    private $address;

    private $name;
    private $phone;

    public function getData(){
        $arr = array(
            "sellerId" => $this->sellerId,
            "refundId" => $this->refundId,
            "prov" => $this->prov,
            "city" => $this->city,
            "area" => $this->area,
            "address" => $this->address,
            "name" => $this->name,
            "phone" => $this->phone,
        );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @return mixed
     */
    public function getSellerId()
    {
        return $this->sellerId;
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @return mixed
     */
    public function getRefundId()
    {
        return $this->refundId;
    }

    /**
     * @param mixed $refundId
     */
    public function setRefundId($refundId)
    {
        $this->refundId = $refundId;
    }

    /**
     * @return mixed
     */
    public function getProv()
    {
        return $this->prov;
    }

    /**
     * @param mixed $prov
     */
    public function setProv($prov)
    {
        $this->prov = $prov;
    }

    /**
     * @return mixed
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * @param mixed $city
     */
    public function setCity($city)
    {
        $this->city = $city;
    }

    /**
     * @return mixed
     */
    public function getArea()
    {
        return $this->area;
    }

    /**
     * @param mixed $area
     */
    public function setArea($area)
    {
        $this->area = $area;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @param mixed $address
     */
    public function setAddress($address)
    {
        $this->address = $address;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @param mixed $phone
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
    }





    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}