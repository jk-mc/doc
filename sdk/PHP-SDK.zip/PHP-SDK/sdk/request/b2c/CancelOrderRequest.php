<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 14:09
 */

class CancelOrderRequest implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "cancelOrder";
    private $apiId = "a6521c0ddd211bff699de0a36b507a31";


    private $sellerId;
    private $tradeId;

    private $cancelMsg = "其他原因";


    public function getData()
    {
        return array('arg1' => $this->sellerId,
            'arg2' => $this->tradeId,
            'arg3' => $this->cancelMsg
        );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $tradeId
     */
    public function setTradeId($tradeId)
    {
        $this->tradeId = $tradeId;
    }

    /**
     * @param string $cancelMsg
     */
    public function setCancelMsg($cancelMsg)
    {
        $this->cancelMsg = $cancelMsg;
    }


    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }

}