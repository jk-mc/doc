<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/7
 * Time: 18:24
 */

class QueryPrescriptionFileForPartnerRequest implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "queryPrescriptionFileForPartner";
    private $apiId = "b4dd4ece39703453b4c1171022110903";


    private $sellerId;
    private $tradeId;

    public function getData()
    {
        return array(
            'arg1' => $this->sellerId,
            'arg2' => $this->tradeId
        );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $tradeId
     */
    public function setTradeId($tradeId)
    {
        $this->tradeId = $tradeId;
    }

    /**
     * @param string $cancelMsg
     */
    public function setCancelMsg($cancelMsg)
    {
        $this->cancelMsg = $cancelMsg;
    }


    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}