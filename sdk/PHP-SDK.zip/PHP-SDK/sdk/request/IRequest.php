<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 11:35
 */

interface IRequest
{

    public function getApiId();
    public function getApiName();
    public function getApiGroup();

    public function getData();
}