<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 17:05
 */

class SearchSpuRequest implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "searchSpu";
    private $apiId = "5f68bbbc62bbd22b2bae6e307e056746";


    private $sellerId;
    private $title = "*";
    private $categoryId = "0";
    private $status = 0;
    private $pageNo = 1;
    private $pageSize = 20;


    public function getData()
    {
        return array(
            "arg1" => $this->sellerId,
            "arg2"=> $this->title ,
            "arg3" => $this->categoryId,
            "arg4" => $this->status,
            "arg5" => $this->pageNo,
            "arg6" => $this->pageSize
        );

    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param string $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @param string $categoryId
     */
    public function setCategoryId($categoryId)
    {
        $this->categoryId = $categoryId;
    }

    /**
     * @param int $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @param int $pageNo
     */
    public function setPageNo($pageNo)
    {
        $this->pageNo = $pageNo;
    }

    /**
     * @param int $pageSize
     */
    public function setPageSize($pageSize)
    {
        $this->pageSize = $pageSize;
    }




    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }


}