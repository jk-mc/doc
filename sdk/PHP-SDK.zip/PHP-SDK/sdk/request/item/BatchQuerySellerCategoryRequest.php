<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 13:55
 */

class BatchQuerySellerCategoryRequest implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "batchQuerySellerCategory";
    private $apiId = "10f1e1abcbf276da37223d5b54bbee7b";


    private $sellerId;



    public function getData()
    {
        return array(
            'arg1' => $this->sellerId
        );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}