<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 17:44
 */

class QuerySpuByIdRequest implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "querySpuById";
    private $apiId = "dbd954fe92410223b8bfa6b3b2d3a262";


    private $sellerId;
    private $spuId;

    public function getData()
    {
        return array(
            "arg1" => $this->sellerId,
            "arg2" => $this->spuId,
        );

    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $spuId
     */
    public function setSpuId($spuId)
    {
        $this->spuId = $spuId;
    }



    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }


}