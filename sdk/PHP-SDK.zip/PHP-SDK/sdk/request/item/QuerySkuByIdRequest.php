<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 17:29
 */

class QuerySkuByIdRequest implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "querySkuById";
    private $apiId = "6e0dacc60ae199b96240be9ae00dd937";


    private $sellerId;
    private $skuId;

    public function getData()
    {
        return array(
            "arg1" => $this->sellerId,
            "arg2" => $this->skuId,
        );

    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $skuId
     */
    public function setSkuId($skuId)
    {
        $this->skuId = $skuId;
    }


    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }

}