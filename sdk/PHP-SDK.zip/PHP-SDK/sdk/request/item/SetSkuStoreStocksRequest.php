<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 15:49
 */

class SetSkuStoreStocksRequest  implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "setSkuStoreStocks";
    private $apiId = "d5e2266a5491e613ec0ebcab4808f8dd";


    private $sellerId;
    private $storeId;
    private $storeOuterId;
    private $skuStoreStockList;


    public function getData()
    {
        $arr = array(
            "sellerId" => $this->sellerId,
            "storeId" => $this->storeId,
            "storeOuterId" => $this->storeOuterId,
            "skuStoreStockList" => $this->skuStoreStockList
        );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $storeId
     */
    public function setStoreId($storeId)
    {
        $this->storeId = $storeId;
    }

    /**
     * @param mixed $storeOuterId
     */
    public function setStoreOuterId($storeOuterId)
    {
        $this->storeOuterId = $storeOuterId;
    }

    /**
     * @param mixed $skuStoreStockList
     */
    public function setSkuStoreStockList($skuStoreStockList)
    {
        $this->skuStoreStockList = $skuStoreStockList;
    }




    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }

}