<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 15:26
 */

class ListSkuRequest  implements IRequest
{



    private $apiGroup = "shennong";
    private $apiName = "listSku";
    private $apiId = "de594726855da2c3cda54afe560a5a01";


    private $sellerId;
    private $skuId;


    public function getData()
    {
        $arr = array("sellerId"=> $this->sellerId, "skuId"=>$this->skuId );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $skuId
     */
    public function setSkuId($skuId)
    {
        $this->skuId = $skuId;
    }




    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}