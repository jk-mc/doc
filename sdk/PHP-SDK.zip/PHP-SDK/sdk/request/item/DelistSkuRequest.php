<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 14:02
 */

class DelistSkuRequest  implements IRequest
{



    private $apiGroup = "shennong";
    private $apiName = "delistSku";
    private $apiId = "de923710d7abda5083a361f8b11ed7b2";


    private $sellerId;
    private $skuId;


    public function getData()
    {
        $arr = array("sellerId"=> $this->sellerId, "skuId"=>$this->skuId );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $skuId
     */
    public function setSkuId($skuId)
    {
        $this->skuId = $skuId;
    }




    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}