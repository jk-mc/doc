<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 18:52
 */

class FindSkuIdBySellerIdAndOuterIdRequest  implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "findSkuIdBySellerIdAndOuterId";
    private $apiId = "9bb2ce64b32f5dd1faac57fb99ec3e84";

    private $sellerId;
    private $skuOuterIds;


    public function getData()
    {
        $arr = array(
            "sellerId" => $this->sellerId,
            "skuOuterIds" => $this->skuOuterIds,
        );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $skuOuterIds
     */
    public function setSkuOuterIds($skuOuterIds)
    {
        $this->skuOuterIds = $skuOuterIds;
    }




    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}