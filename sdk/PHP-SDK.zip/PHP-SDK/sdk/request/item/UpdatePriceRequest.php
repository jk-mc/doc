<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 16:53
 */

class UpdatePriceRequest  implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "updatePrice";
    private $apiId = "7cbb253647549c2b9613149dbce0c4a5";


    private $sellerId;
    private $skuId;
    private $storeId;
    private $storeReferId = "*";
    private $priceType = "selling_price";
    private $price;


    public function getData()
    {
        return array(
            "arg1" => $this->sellerId,
            "arg2"=> $this->skuId,
            "arg3" => $this->storeId,
            "arg4" => $this->storeReferId,
            "arg5" => $this->priceType,
            "arg6" => $this->price
        );

    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $skuId
     */
    public function setSkuId($skuId)
    {
        $this->skuId = $skuId;
    }

    /**
     * @param mixed $storeId
     */
    public function setStoreId($storeId)
    {
        $this->storeId = $storeId;
    }

    /**
     * @param mixed $storeReferId
     */
    public function setStoreReferId($storeReferId)
    {
        $this->storeReferId = $storeReferId;
    }

    /**
     * @param mixed $priceType
     */
    public function setPriceType($priceType)
    {
        $this->priceType = $priceType;
    }

    /**
     * @param mixed $price 单位:分
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }

    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }

}