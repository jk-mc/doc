<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 19:18
 */

class FindSkuStoreStocksRequest implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "findSkuStoreStocks";
    private $apiId = "c193d5ffcb9f15f8ee88ae9ccc667b30";

    private $sellerId;
    private $storeId;
    private $storeOuterId;
    private $skuIdList;

    public function getData()
    {
        $arr = array(
            "sellerId" => $this->sellerId,
            "storeId" => $this->storeId,
            "storeOuterId" => $this->storeOuterId,
            "skuIdList" => $this->skuIdList
        );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $skuIdList
     */
    public function setSkuIdList($skuIdList)
    {
        $this->skuIdList = $skuIdList;
    }

    /**
     * @param mixed $storeId
     */
    public function setStoreId($storeId)
    {
        $this->storeId = $storeId;
    }

    /**
     * @param mixed $storeOuterId
     */
    public function setStoreOuterId($storeOuterId)
    {
        $this->storeOuterId = $storeOuterId;
    }





    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}