<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 18:40
 */

class QuerySkuByOuterSkuIdRequest implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "querySkuByOuterSkuId";
    private $apiId = "9154e11e637027bc0a9d7d281b6e2124";

    private $sellerId;
    private $outerSkuId ;


    public function getData()
    {
        return array(
            "arg1" => $this->sellerId,
            "arg2" => $this->outerSkuId,
        );

    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $outerSkuId
     */
    public function setOuterSkuId($outerSkuId)
    {
        $this->outerSkuId = $outerSkuId;
    }





    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }
}