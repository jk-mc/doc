<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 17:20
 */

class SetSkuStorePricesRequest implements IRequest
{


    private $apiGroup = "shennong";
    private $apiName = "setSkuStorePrices";
    private $apiId = "fddd6b8a683e388ee7b9b53591191366";


    private $sellerId;
    private $storeId;
    private $storeOuterId;
    private $skuStorePriceList;


    public function getData()
    {
        $arr = array(
            "sellerId" => $this->sellerId,
            "storeId" => $this->storeId,
            "storeOuterId" => $this->storeOuterId,
            "skuStorePriceList" => $this->skuStorePriceList
        );
        return array(
            'arg1' => json_encode($arr)
        );
    }

    /**
     * @param mixed $sellerId
     */
    public function setSellerId($sellerId)
    {
        $this->sellerId = $sellerId;
    }

    /**
     * @param mixed $storeId
     */
    public function setStoreId($storeId)
    {
        $this->storeId = $storeId;
    }

    /**
     * @param mixed $storeOuterId
     */
    public function setStoreOuterId($storeOuterId)
    {
        $this->storeOuterId = $storeOuterId;
    }

    /**
     * @param mixed $skuStorePriceList
     */
    public function setSkuStorePriceList($skuStorePriceList)
    {
        $this->skuStorePriceList = $skuStorePriceList;
    }

    public function getApiId()
    {
        return $this->apiId;
    }

    public function getApiName()
    {
        return $this->apiName;
    }

    public function getApiGroup()
    {
        return $this->apiGroup;
    }


}