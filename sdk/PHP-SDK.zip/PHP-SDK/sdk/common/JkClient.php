<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 11:26
 */

class JkClient
{
    function __construct($partnerId, $key, $myEnv)
    {
        $this->partnerId = $partnerId;
        $this->key = $key;
        $this->myEnv = $myEnv;
        //实例化加解密类
        $this->encrypt = $this->buildCrypt3Des();
        $this->version = "0.1.0";
        $this->curl = Curl::instance()->header('Content-Type', 'Content-Type: application/x-www-form-urlencoded; charset=utf-8');
    }




    function execute($request){

        //随机数
        $rand = self::randomFloat();
        //加密参数

        $data = $request->getData();
//        echo "\n";
//        var_dump($data) ;

        $data = self::buildDate($request->getApiId(), $rand, $data);

        $url = self::getUrl($request->getApiGroup(), $request->getApiName(), $data, $rand);

        $dataArray = array(
            'q' => $data
        );

        echo "\n". $url. "\n". $data."\n";

        return $this->doQuery($url, $dataArray);


    }



    function getUrl($apiGroup, $apiName,$data, $rand){

        $sign = $this->sign($data . $rand, $this->key);
        //请求参数
        $param = 'p='.$this->partnerId.'&v='.$this->version.'&s='.$rand.'&h='.$sign;
        // return $apiGroup.'/'.$apiName."?".$param;
        return $this->myEnv->url .$apiGroup.'/'.$apiName."?".$param;
    }




    function buildDate($apiId, $rand, $data = array()){
        $data = array_merge(array('__o_s'=>$apiId."#" . $this->myEnv->env, '__o_v'=>$this->version), $data, array('__o_r'=>$rand));
        var_dump("==================================");
        var_dump($data);
        return $this->encrypt->encrypt(urldecode(http_build_query($data)));
    }



    function buildCrypt3Des (){
        $key = md5($this->key);  //对key进行md5加密
        $i_key = pack('H48', $key.substr($key, 0, 16));  // 把48位字符串转为16位字节
        $i_iv = pack('H16','0000000000000000');

        //实例化加解密类
        return new Crypt3Des($i_key,$i_iv);
    }

    function randomFloat($min = 0, $max = 1000000) {
        return $min + mt_rand() / mt_getrandmax() * ($max - $min);
    }

    public function sign($str, $key){

        return bin2hex(hash_hmac('sha1', $str, $key, true));
    }


    function doQuery($url, $data)
    {

        $result = $this->curl->url($url)->data($data)->get();
        var_dump($result);
        return $this->response($result);
    }


    private function response($result){
        $data = json_decode($result);
        if(empty($data)){
            return new BaseResult(-1, "网络请求错误");
        }

        if(0 !== $data->code){
            return new BaseResult(-101, "解析api网关错误， 错误码:".$data->code."， 错误信息：".$data->message.", tips:".$data->tips );
        }

        if(empty($data->object)){
            return new BaseResult(-102, "加密数据为空");
        }
        parse_str($data->object, $input);



        $sign = $this->sign($input['d'] . $input['s'], $this->key);
        if($sign !== $input['h']){
            return new BaseResult(-103, "签名不正确");
        }
        $result_arr = $this->encrypt->decrypt($input['d']);


        $arr_decrypt = explode('&', $result_arr);
        $arr_first = explode('=', $arr_decrypt[0]);
        $arr_first = urldecode($arr_first[1]);

        return json_decode($arr_first,true, 512,JSON_BIGINT_AS_STRING);
    }
}