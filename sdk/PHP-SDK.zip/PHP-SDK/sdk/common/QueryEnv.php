<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/27
 * Time: 15:32
 */

class QueryEnv
{

    var $DEV  = "LATEST";
    var $TEST = "TEST";
    var $PROD = "PROD";

    var $DEV_URL  = "http://openapi.dev.pajk.cn/api/v1/";
    var $TEST_URL = "http://openapi.test.pajk.cn/api/v1/";
    var $PROD_URL = "http://openapi.jk.cn/api/v1/";



    function getDev(){
        return new MyEnv($this->DEV, $this->DEV_URL);
    }

    function getTest(){
        return new MyEnv($this->TEST, $this->TEST_URL);
    }

    function getProd(){
        return new MyEnv($this->PROD, $this->PROD_URL);
    }


}


class MyEnv
{
    public $env;
    public $url;

    function __construct( $i_env, $i_url)
    {
        $this->env = $i_env;
        $this->url =$i_url;
    }

}