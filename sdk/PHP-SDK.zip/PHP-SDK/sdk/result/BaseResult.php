<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 10:25
 */

class BaseResult
{
    var $resultMsg;
    var $resultCode;

    function __construct( $code, $msg)
    {
        $this->resultCode = $code;
        $this->resultMsg = $msg;
    }
}