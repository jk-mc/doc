<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 19:20
 */

include "Autoloader.php";

$key = "0031ae2efaacd0fe644580de630f9d13";
$partnerId = "yaofang_test_01";




$items=array("911911888658578");
$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new FindSkuStoreStocksRequest();
$request->setSellerId("21319590608");
$request->setStoreId("21329280606");
$request->setSkuIdList($items);
$result =$client->execute($request);
var_dump($result);
