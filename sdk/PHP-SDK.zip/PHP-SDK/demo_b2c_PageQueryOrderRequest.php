<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 14:19
 */

include "Autoloader.php";

$key = "0031ae2efaacd0fe644580de630f9d13";
$partnerId = "yaofang_test_01";
$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new PageQueryOrderRequest();
$request->setSellerId("21319590608");
$request->setStartTime(time() - 86400 * 30);
$request->setEndTime( time() - 86400);
$request->setOrderStatus("DELIVERY");
$request->setOrderType("0");
$request->setPageNo(1);
$request->setPageSize(1);
$result =$client->execute($request);
var_dump($result);
