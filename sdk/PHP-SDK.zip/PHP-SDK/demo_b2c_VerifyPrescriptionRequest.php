<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 16:21
 */

include "Autoloader.php";

$key = "0031ae2efaacd0fe644580de630f9d13";
$partnerId = "yaofang_test_01";
$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new VerifyPrescriptionRequest();
$request->setSellerId("21319590608");
$request->setTradeId("9283340303");
$request->setVerifyStatus(1);
$request->setVerifyMsg("ok");
$result =$client->execute($request);
var_dump($result);
