<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/30
 * Time: 16:59
 */



include "Autoloader.php";

$key = "0031ae2efaacd0fe644580de630f9d13";
$partnerId = "yaofang_test_01";


$polygons = "121.462503 31.189759,121.462604 31.189237,121.462974 31.188533,121.463112 31.18919,121.462503 31.189759";
$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new UpdateStorePolygonsByIdRequest();
$request->setSellerId("2523760705");
$request->setStoreReferId(QMY0001123123);
$request->setPolygons($polygons);
$result =$client->execute($request);
var_dump($result);
