<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/27
 * Time: 17:47
 */


class Autoloader{
    public static function autoload($class) {
        $name = $class;
        if(false !== strpos($name,'\\')){
            $name = strstr($class, '\\', true);
        }

        $filePaths = array(
            "/sdk/common/",
            "/sdk/request/",
            "/sdk/request/o2o/",
            "/sdk/request/b2c/",
            "/sdk/request/b2c/trade/",
            "/sdk/request/b2c/refund/",
            "/sdk/request/store/",
            "/sdk/request/item/",
            "/sdk/result/"

            );

        foreach ($filePaths as $filePath){
            $filename = __DIR__.$filePath.$name.".php";
            #echo "\n".$filename."\n";
            if(is_file($filename)) {
                include $filename;
                return;
            }
        }

//        $filename = __DIR__."/sdk/common/".$name.".php";
//        #echo "\n".$filename."\n";
//        if(is_file($filename)) {
//            include $filename;
//            return;
//        }
//
//        $filename = __DIR__."/sdk/request/".$name.".php";
//        if(is_file($filename)) {
//            include $filename;
//            return;
//        }
//        $filename = __DIR__."/sdk/request/o2o/".$name.".php";
//        if(is_file($filename)) {
//            include $filename;
//            return;
//        }
//        $filename = __DIR__."/sdk/request/b2c/".$name.".php";
//        if(is_file($filename)) {
//            include $filename;
//            return;
//        }
//        $filename = __DIR__."/sdk/request/b2c/trade/".$name.".php";
//        if(is_file($filename)) {
//            include $filename;
//            return;
//        }
//        $filename = __DIR__."/sdk/request/b2c/refund/".$name.".php";
//        if(is_file($filename)) {
//            include $filename;
//            return;
//        }
//        $filename = __DIR__."/sdk/request/store/".$name.".php";
//        if(is_file($filename)) {
//            include $filename;
//            return;
//        }
//        $filename = __DIR__."/sdk/request/item/".$name.".php";
//        if(is_file($filename)) {
//            include $filename;
//            return;
//        }
//        $filename = __DIR__."/sdk/result/".$name.".php";
//        if(is_file($filename)) {
//            include $filename;
//            return;
//        }


    }
}

spl_autoload_register('Autoloader::autoload');
?>
