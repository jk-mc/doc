<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/27
 * Time: 17:52
 */


include "Autoloader.php";

$key = "0031ae2efaacd0fe644580de630f9d13";
$partnerId = "yaofang_test_01";

$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new BatchQueryB2CCarrierRequest;
$result =$client->execute($request);
var_dump($result);
