<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/27
 * Time: 18:09
 */

echo "hello";