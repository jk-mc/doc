<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/29
 * Time: 17:01
 */



include "Autoloader.php";

$key = "0031ae2efaacd0fe644580de630f9d13";
$partnerId = "yaofang_test_01";
$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new PageQueryRefundByTradeIdRequest();
$request->setSellerId("21319590608");
$request->setTradeId("10006430709");
$request->setPageNo(1);
$request->setPageSize(1);
$result =$client->execute($request);
var_dump($result);