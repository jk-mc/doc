<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 13:57
 */



include "Autoloader.php";


$key = "d2d03a99b8227686aaa7d47a4535419a";
$partnerId = "yaofang_test_03";

$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new BatchQuerySellerCategoryRequest();
$request->setSellerId("989810607");
$result =$client->execute($request);
var_dump($result);
