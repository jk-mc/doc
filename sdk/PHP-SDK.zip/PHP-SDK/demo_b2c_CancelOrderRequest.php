<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng
 * Date: 18/4/28
 * Time: 14:12
 */

include "Autoloader.php";

$key = "0031ae2efaacd0fe644580de630f9d13";
$partnerId = "yaofang_test_01";

$env = new QueryEnv();
$request = new CancelOrderRequest();
$request->setSellerId("21319590608");
$request->setTradeId("9707270200");
$request->setCancelMsg("用户不要了");
$client = new JkClient($partnerId,$key,$env->getTest());
$result =$client->execute($request);
var_dump($result);
