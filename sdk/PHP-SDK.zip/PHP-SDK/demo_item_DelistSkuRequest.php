<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 14:09
 */

include "Autoloader.php";

$key = "0031ae2efaacd0fe644580de630f9d13";
$partnerId = "yaofang_test_01";


$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new DelistSkuRequest();
$request->setSellerId("21319590608");
$request->setSkuId("911911888658578");
$result =$client->execute($request);
var_dump($result);
