<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/29
 * Time: 17:05
 */


include "Autoloader.php";

$key = "0031ae2efaacd0fe644580de630f9d13";
$partnerId = "yaofang_test_01";
$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new PageQueryRefundIncrementRequest();
$request->setSellerId("21319590608");
$request->setStartTime(date("Y-m-d H:i:s",(time()-86400*1)));
$request->setEndTime( date("Y-m-d H:i:s",time()));
$request->setStatus("ALL");
$request->setPageNo(1);
$request->setPageSize(1);
$result =$client->execute($request);
var_dump($result);


