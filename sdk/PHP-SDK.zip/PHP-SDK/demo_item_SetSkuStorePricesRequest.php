<?php
/**
 * Created by PhpStorm.
 * User: fanhuafeng925
 * Date: 2018/5/8
 * Time: 17:24
 */

include "Autoloader.php";

$key = "dd6b10e05cf9fd74a55bc83d8cfe217a";
$partnerId = "qumaiyao_test";

$item1=array("skuId"=>"911911888319149", "price"=>123);
$item2=array("skuId"=>"911911888619922", "price"=>456);
$items=array($item1, $item2);
$env = new QueryEnv();
$client = new JkClient($partnerId,$key,$env->getTest());
$request = new SetSkuStorePricesRequest();
$request->setSellerId("2523760705");
$request->setStoreId("2541240602");
$request->setSkuStorePriceList($items);
$result =$client->execute($request);
var_dump($result);
