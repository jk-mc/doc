using System;
using System.Collections.Generic;


namespace queryAll
{
    [Serializable]
    class PageQueryRefundByTradeIdParam
    {
        private long? sellerId;
        private String tradeId;
        private int? pageNo;
        private int? pageSize;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }


        public String getTradeId()
        {
            return this.tradeId;
        }

        public void setTradeId(String tradeId)
        {
            this.tradeId = tradeId;
        }

    
        public int? getPageNo()
        {
            return this.pageNo;
        }

        public void setPageNo(int? pageNo)
        {
            this.pageNo = pageNo;
        }


        public int? getPageSize()
        {
            return this.pageSize;
        }

        public void setPageSize(int? pageSize)
        {
            this.pageSize = pageSize;
        }





    }


}