using System;

namespace queryAll
{
    [Serializable]
    class SkuStoreStockParam
    {

        private long? skuId;
        private long? stockNum;

        public long? getSkuId()
        {
            return this.skuId;
        }

        public void setSkuId(long? skuId)
        {
            this.skuId = skuId;
        }

        public long? getStockNum()
        {
            return this.stockNum;
        }

        public void setStockNum(long? stockNum)
        {
            this.stockNum = stockNum;
        }

    }


}