using System;
using System.Collections.Generic;


namespace queryAll
{
    [Serializable]
    class FindSkuIdBySellerIdAndOuterIdParam
    {
         private long? sellerId;
        private IList<String> skuOuterIds;


        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

       
        public IList<String> getSkuOuterIds()
        {
            return skuOuterIds;
        }

        public void setSkuOuterIds(IList<String> skuOuterIds)
        {
            this.skuOuterIds = skuOuterIds;
        }




    }


}