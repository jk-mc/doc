using System;
using System.Collections.Generic;


namespace queryAll
{
    [Serializable]
    class FindSkuStoreStocksParam
    {
        private long? sellerId;
        private long? storeId;
        private String storeOuterId;
        private IList<long?> skuIdList;


        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

       


        public long? getStoreId()
        {
            return storeId;
        }

        public void setStoreId(long? storeId)
        {
            this.storeId = storeId;
        }

        public String getStoreOuterId()
        {
            return storeOuterId;
        }

        public void setStoreOuterId(String storeOuterId)
        {
            this.storeOuterId = storeOuterId;
        }

        public IList<long?> getSkuIdList()
        {
            return skuIdList;
        }

        public void setSkuIdList(IList<long?> skuIdList)
        {
            this.skuIdList = skuIdList;
        }



    }


}