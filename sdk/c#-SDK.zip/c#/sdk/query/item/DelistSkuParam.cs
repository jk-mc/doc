using System;

namespace queryAll
{
    [Serializable]
    class DelistSkuParam
    {
        private long? sellerId;
        private long? skuId;

        public long? getSkuId()
        {
            return this.skuId;
        }

        public void setSkuId(long? skuId)
        {
            this.skuId = skuId;
        }

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }


    }


}