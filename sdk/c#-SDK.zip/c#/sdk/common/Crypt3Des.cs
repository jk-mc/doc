using System;
using System.Security.Cryptography;
using System.Text;


namespace commonUtil {

    class Crypt3Des {

         public static String Encrypt(string Text, string sKey)
        {
            byte[] inputByteArray;
            inputByteArray = Encoding.UTF8.GetBytes(Text);

            byte[] iv = new byte[8];//des 向量  

            //MD5
            MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
            byte[] byteOriginal = hashmd5.ComputeHash(Encoding.UTF8.GetBytes(sKey));
            byte[] DesKey = new byte[24];
            byteOriginal.CopyTo(DesKey, 0);
            for (int i = 0; i < 8; i++)
            {
                DesKey[16 + i] = byteOriginal[i];
            }

            TripleDES des = TripleDES.Create();

            des.Key = DesKey;
            des.Mode = CipherMode.CBC;
            des.Padding = PaddingMode.PKCS7;
            des.IV = iv;

            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            StringBuilder ret = new StringBuilder();
            foreach (byte b in ms.ToArray())
            {
                ret.AppendFormat("{0:x2}", b);
            }
            return ret.ToString();
        }

        //解密
        public static String Decrypt(string str, string sKey)
        {
            System.Security.Cryptography.TripleDESCryptoServiceProvider des = new System.Security.Cryptography.TripleDESCryptoServiceProvider();
            //byte[] inputByteArray = Encoding.UTF8.GetBytes(str);
            byte[] inputByteArray = new Byte[str.Length / 2];
            for (int x = 0; x < str.Length / 2; x++)
                inputByteArray[x] = (byte)(Convert.ToInt32(str.Substring(x * 2, 2), 16));


            byte[] iv = new byte[8];//des 向量  
            //MD5
            MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
            byte[] byteOriginal = hashmd5.ComputeHash(Encoding.UTF8.GetBytes(sKey));
            byte[] DesKey = new byte[24];
            byte[] DesIV = new byte[8];
            byteOriginal.CopyTo(DesKey, 0);
            for (int i = 0; i < 8; i++)
            {
                DesKey[16 + i] = byteOriginal[i];
                DesIV[i] = byteOriginal[i];
            }

            des.Mode = CipherMode.CBC;
            des.Padding = PaddingMode.PKCS7;
            des.Key = DesKey;
            des.IV = iv;
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            System.Security.Cryptography.CryptoStream cs = new System.Security.Cryptography.CryptoStream(ms, des.CreateDecryptor(), System.Security.Cryptography.CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            System.Text.StringBuilder ret = new System.Text.StringBuilder();

            return System.Text.Encoding.UTF8.GetString(ms.ToArray());
        }   
    }

}