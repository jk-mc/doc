using System;
using System.Security.Cryptography;
using System.Text;
using System.Collections;

using requestAll;
using resultAll;


namespace commonUtil

{
    class JkClient {
        private ENV env;
        private string partnerId;
        private string key;
        private string version = "0.1.0";

        public JkClient(String partnerId, String key, ENV env){
            this.env = env;
            this.partnerId = partnerId;
            this.key = key;
        }        

        public T execute<T>(IRequest<T> request) where T : BaseResult{


            QueryResult query = new QueryResult();
            
            //geturl salt
            Random random = new Random();
            double salt = random.NextDouble();
            
            //参数加密串
            string encryptStr = getEncryptStr(request,version,salt);

            //签名
            string sign = HMACSHA1Encrypt(encryptStr, key, salt);

            //请求url
            string requestUrlParam = getRequestUrlParam(version,salt,sign);

            string requestUrl = getUrl(request.getApiGroup(),request.getApiName(),requestUrlParam);

            //请求数据
            string requestData = getRequestData(encryptStr);

            //dopost
            QueryResult result = execute(requestUrl, requestData);

            if(!result.isSuccess()){
                BaseResult baseResult = new BaseResult(result.getResultCode(), result.getResultMsg());
                result.setModel(JsonUtil.ToJsonString(baseResult));

                Type type = typeof(T);

                object[] parameters = new object[2];
                parameters[0] = result.getResultCode();
                parameters[1] = result.getResultMsg();
                object obj = type.Assembly.CreateInstance(type.FullName,true,System.Reflection.BindingFlags.Default,null,parameters,null,null);

                return (T)obj;
            }

            return JsonUtil.ToJsonObject<T>(result.getModel());

        }

        private QueryResult execute(string url, string data){
             QueryResult result = doPost(url,data);


             if(!result.isSuccess()){
                return result;
            }

            QueryResult result1 = new QueryResult();

            ResponseObject o = JsonUtil.ToJsonObject<ResponseObject>(result.getModel());

            if(null == o){
                result1 = new QueryResult(-1,"网络请求错误");
                return result1;
            }

            if (0 != Convert.ToInt32(o.code)){
                result1 = new QueryResult(-101, "解析api网关错误， 错误码："+o.code + "， 错误信息："
                    + o.message + ", " + o.tips );
                return result1;

            }
            if(string.IsNullOrEmpty(o.@object)){
                result1 = new QueryResult(-102, "加密数据为空");
                return result1;
            }

            String[] arrayStr = o.@object.Split('&');
            ResponseParam responseParam = new ResponseParam();
            for (int i = 0; i < arrayStr.Length; i++)
            {
                String[] ss = arrayStr[i].Split('=');
                if (ss[0] == "s")
                {
                    responseParam.S = ss[1];
                }
                else if(ss[0] == "d")
                {
                    responseParam.D = ss[1];
                }
                else if (ss[0] == "h")
                {
                    responseParam.H = ss[1];
                }
            }


            //签名
            String responseSign = HMACSHA1Encrypt(responseParam.D, key, Convert.ToDouble(responseParam.S));
            //验签
            if(responseSign != responseParam.H){
                result1 = new QueryResult(-103, "解析api网关错误 : 签名不正确" );
                return result1;
            }

            //解密
            string resultStr = Crypt3Des.Decrypt(responseParam.D, key);
            string[] results = resultStr.Split("&");
            string reModel = results[0].Split("=")[1];

            String reStr = System.Web.HttpUtility.UrlDecode(reModel, System.Text.Encoding.GetEncoding("UTF-8"));

            result1.setModel(reStr);
            return result1;

        }

        //发送请求
        public QueryResult doPost(String url, String sendData)
        {

            string backMsg = "";
            try
            {
                System.Net.WebRequest httpRequest = System.Net.HttpWebRequest.Create(url);
                httpRequest.Method = "POST";
                //这行代码很关键，不设置ContentType将导致后台参数获取不到值
                httpRequest.ContentType = "application/x-www-form-urlencoded;charset=UTF-8";
                byte[] dataArray = System.Text.Encoding.UTF8.GetBytes(sendData);
                //httpRquest.ContentLength = dataArray.Length;
                System.IO.Stream requestStream = null;
                if (string.IsNullOrWhiteSpace(sendData) == false)
                {
                    requestStream = httpRequest.GetRequestStream();
                    requestStream.Write(dataArray, 0, dataArray.Length);
                    requestStream.Close();
                }
                System.Net.WebResponse response = httpRequest.GetResponse();
                System.IO.Stream responseStream = response.GetResponseStream();
                System.IO.StreamReader reader = new System.IO.StreamReader(responseStream, System.Text.Encoding.UTF8);
                backMsg = reader.ReadToEnd();

                reader.Close();
                reader.Dispose();

                requestStream.Dispose();
                responseStream.Close();
                responseStream.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine("---------=============Exception=");
                return new QueryResult(-100, "IOException"+ e.ToString());
            }

            QueryResult result = new QueryResult();
            result.setModel(backMsg);
            return result;
        }

        private string getRequestData(string ecryptStr){
            return "q=" + ecryptStr;
        }

        private string getRequestUrlParam(string version, double salt, string sign){
            return "p=" + partnerId
                + "&v=" + version
                + "&s=" + salt
                + "&h=" + sign;
        }

        private string getEncryptStr<T>(IRequest<T> request, string version, double salt) where T : BaseResult{
            string p = getParamKV(request);
            string apiId = getQueryApiId(request.getApiId());
            string sign = getSignData(apiId,version,p,salt);
            return Crypt3Des.Encrypt(sign,key);
            
        }

        private string getParamKV<T>(IRequest<T> request) where T : BaseResult{
            IList list = request.getData();
            string p = "";
            

            if(null!=list){
                for(int i=0; i<list.Count ; i++){
                    Object o = list[i];
                    string pOne = "&arg" + (1 + i ) + "=";
                    if(null == o){
                        pOne += o;     
                    }else{
                        bool a = !(o.GetType().IsValueType || o is string);
                        if(a){
                            pOne += JsonUtil.ToJsonString(o.GetType(),o); 
                        }else{
                            pOne += o;
                        }
                    }
                    p += pOne;
                }
                
            }

            return p;

        }
        private string getSignData(string apiId, string version,string param, double salt){
            return  "__o_s="+ apiId
             + "&__o_v=" + version 
             + param   
             + "&__o_r=" + salt;            
        }

        private string getQueryApiId(string apiId){
            return apiId + "#" +env.getEnv();
        }

        private String getUrl(String apiGroup ,String apiName, String param){
            return env.getUrl() +  apiGroup + "/" + apiName +  "?" + param;
        }

        //签名
        public static String HMACSHA1Encrypt(string text, string key, Double salt)
        {
            using (var hmACSHA1 = new HMACSHA1(Encoding.UTF8.GetBytes(key)))
            {
                byte[] hashBytes = hmACSHA1.ComputeHash(Encoding.UTF8.GetBytes(text + salt));
                var sb = new StringBuilder();
                foreach (var _b in hashBytes)
                    sb.AppendFormat("{0:x2}", _b);

                return sb.ToString();
            }
        }

    }

    public class ResponseObject
    {
        public String message { get; set; }
        public String @object { get; set; }
        public String tips { get; set; }
        public String code { get; set; }
        public String version { get; set; }

        public ResponseObject()
        {
            
            message = "";
            @object = "";
            tips = "";
            code = "";
            version = "";
        }
    }

    //获取响应实际值
    public class ResponseParam
    {
        public String S { get; set; }
        public String D { get; set; }
        public String H { get; set; }

        public ResponseParam()
        {
            S = "";
            D = "";
            H = "";
        }
    }

    
}