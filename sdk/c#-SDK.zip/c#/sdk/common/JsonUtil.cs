using System;
using System.Runtime.Serialization.Json;
using System.IO;


namespace commonUtil

{
    public static class JsonUtil {
        
        public static string ToJsonString<T>(this T instance)
        {
            
            Type t = typeof(T);
            return ToJsonString(t,instance);
        }

        public static string ToJsonString(Type t, Object instanse)
        {
            try
            {
                DataContractJsonSerializer js = new DataContractJsonSerializer(t);
                using (MemoryStream ms = new MemoryStream())
                {
                    js.WriteObject(ms, instanse);
                    ms.Flush();
                    ms.Seek(0, SeekOrigin.Begin);
                    StreamReader sr = new StreamReader(ms);
                    return sr.ReadToEnd();
                }
            }
            catch(Exception e)
            {
                Console.WriteLine("-----JsonUtil------ToJsonString-----"+  e.Message);
                return string.Empty;
            }
        }

        /// <summary>
        /// 将字符串转化为JSON对象，如果转换失败，返回default(T)
        /// </summary>
        /// <typeparam name="T">对象类型</typeparam>
        /// <param name="s">字符串</param>
        /// <returns>转换值</returns>
        public static T ToJsonObject<T>(this string s)
        {
            try
            {
                DataContractJsonSerializer js = new DataContractJsonSerializer(typeof(T));
                using (MemoryStream ms = new MemoryStream())
                {
                    StreamWriter sw = new StreamWriter(ms);
                    sw.Write(s);
                    sw.Flush();
                    ms.Seek(0, SeekOrigin.Begin);
                    return (T)js.ReadObject(ms);
                }
            }
            catch(Exception e)
            {
                Console.WriteLine("-----JsonUtil------ToJsonObject-----"+  e.Message + "---------------------!!"+ s);

                return default(T);
            }
        }
    }

}