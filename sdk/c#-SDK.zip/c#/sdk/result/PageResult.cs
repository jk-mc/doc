using System;

namespace resultAll 
{
    [Serializable]
    class PageResult : BaseResult {

        private int? totalCount;
        private int? pageNo;
        private int? pageSize;

        public PageResult(int? code, String msg) : base(code, msg){}

        public PageResult(){}

        private int? getTotalCount(){
            return this.totalCount;
        }

        private void setTotalCount(int? totalCount){
            this.totalCount = totalCount;
        }

        private int? getPageNo(){
            return this.pageNo;
        }

        private void setPageNo(int? pageNo){
            this.pageNo = pageNo;   
        }

        private int? getPageSize(){
            return this.pageSize;
        }

        private void setPageSize(int? pageSize){
            this.pageSize = pageSize;
        }
    }


    
}