using System;
using System.Collections;


namespace resultAll
{
    [Serializable]
    class TradeFullResult
    {
        private OrderBizResult bizOrder;

        private OrderPayResult payOrder;

        private OrderLgResult lgOrder;

        private OrderInvoiceResult invoice;

        public OrderBizResult getBizOrder()
        {
            return bizOrder;
        }

        public void setBizOrder(OrderBizResult bizOrder)
        {
            this.bizOrder = bizOrder;
        }

        public OrderPayResult getPayOrder()
        {
            return payOrder;
        }

        public void setPayOrder(OrderPayResult payOrder)
        {
            this.payOrder = payOrder;
        }

        public OrderLgResult getLgOrder()
        {
            return lgOrder;
        }

        public void setLgOrder(OrderLgResult lgOrder)
        {
            this.lgOrder = lgOrder;
        }

        public OrderInvoiceResult getInvoice()
        {
            return invoice;
        }

        public void setInvoice(OrderInvoiceResult invoice)
        {
            this.invoice = invoice;
        }



    }


}