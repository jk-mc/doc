using System;

namespace resultAll
{
    [Serializable]
    class UpdateEmsResult : BaseResult
    {
        public UpdateEmsResult()
        {
        }
        public UpdateEmsResult(int code, String msg) : base(code, msg) { }

    }



}