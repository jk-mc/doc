using System;

namespace resultAll
{
    [Serializable]
    class CancelOrderResult : BaseResult{
        public CancelOrderResult() {
        }
        public CancelOrderResult(int code, String msg) : base(code,msg) {}

    }



}