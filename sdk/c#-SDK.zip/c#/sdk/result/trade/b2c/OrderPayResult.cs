using System;
using System.Collections.Generic;  


namespace resultAll
{
    [Serializable]
    class OrderPayResult
    {
        /**
        * 实际支付运费
        */
        private long? actualPostFee;

        /**
         * 原始邮费
         */
        private long? originalPostFee;

        /**
         * 支付详情
         */
        private IList<OrderPayItemResult> payItems;

        public long? getActualPostFee()
        {
            return actualPostFee;
        }

        public void setActualPostFee(long? actualPostFee)
        {
            this.actualPostFee = actualPostFee;
        }

        public long? getOriginalPostFee()
        {
            return originalPostFee;
        }

        public void setOriginalPostFee(long? originalPostFee)
        {
            this.originalPostFee = originalPostFee;
        }

        public IList<OrderPayItemResult> getPayItems()
        {
            return payItems;
        }

        public void setPayItems(IList<OrderPayItemResult> payItems)
        {
            this.payItems = payItems;
        }



    }


}