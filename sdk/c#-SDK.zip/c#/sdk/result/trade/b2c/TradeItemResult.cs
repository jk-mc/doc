using System;

namespace resultAll
{
    [Serializable]
    class TradeItemResult
    {
        /**
        * 商品id
        */
        private String spuId;
        /**
        * skuId
        */
        private String skuId;
        /**
        * 外部商户skuId
        */
        private String outSkuId;
        /**
         * 商品名
         */
        private String title;
        /**
        * 商品售价
        */
        private String sellPrice;
        /**
        * 商品结算价
        */
        private String settlePrice;
        /**
        * 订单商品 实际支付现金
        */
        private String cashFee;
        /**
        * 订单商品税费 实际支付现金
        */
        private String cashTaxFee;
        /**
        * 商品佣金比率
        */
        private String rebateRatio;
        /**
        * 购买数量
        */
        private String buyCount;
        /**
        * 退款数量
        */
        private String refundCount;

        /**
        * 扩展属性
        * 如好眼睛验光属性
        */
        private String extProps;

        public String getSpuId() {
            return spuId;
        }

        public void setSpuId(String spuId) {
            this.spuId = spuId;
        }

        public String getSkuId() {
            return skuId;
        }

        public void setSkuId(String skuId) {
            this.skuId = skuId;
        }

        public String getOutSkuId() {
            return outSkuId;
        }

        public void setOutSkuId(String outSkuId) {
            this.outSkuId = outSkuId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getSellPrice() {
            return sellPrice;
        }

        public void setSellPrice(String sellPrice) {
            this.sellPrice = sellPrice;
        }

        public String getSettlePrice() {
            return settlePrice;
        }

        public void setSettlePrice(String settlePrice) {
            this.settlePrice = settlePrice;
        }

        public String getCashFee() {
            return cashFee;
        }

        public void setCashFee(String cashFee) {
            this.cashFee = cashFee;
        }

        public String getCashTaxFee() {
            return cashTaxFee;
        }

        public void setCashTaxFee(String cashTaxFee) {
            this.cashTaxFee = cashTaxFee;
        }

        public String getRebateRatio() {
            return rebateRatio;
        }

        public void setRebateRatio(String rebateRatio) {
            this.rebateRatio = rebateRatio;
        }

        public String getBuyCount() {
            return buyCount;
        }

        public void setBuyCount(String buyCount) {
            this.buyCount = buyCount;
        }

        public String getRefundCount() {
            return refundCount;
        }

        public void setRefundCount(String refundCount) {
            this.refundCount = refundCount;
        }

        public String getExtProps() {
            return extProps;
        }

        public void setExtProps(String extProps) {
            this.extProps = extProps;
        }


    }


}