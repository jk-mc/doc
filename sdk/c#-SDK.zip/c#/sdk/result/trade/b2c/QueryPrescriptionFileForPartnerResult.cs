using System;

namespace resultAll
{
    [Serializable]
    class QueryPrescriptionFileForPartnerResult : BaseResult
    {
        public QueryPrescriptionFileForPartnerResult()
        {
        }
        public QueryPrescriptionFileForPartnerResult(int code, String msg) : base(code, msg) { }

        private String model;

        public String getModel()
        {
            return model;
        }

        public void setModel(String model)
        {
            this.model = model;
        }

    }



}