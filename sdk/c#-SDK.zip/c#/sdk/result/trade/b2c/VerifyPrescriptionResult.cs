using System;

namespace resultAll
{
    [Serializable]
    class VerifyPrescriptionResult : BaseResult
    {
        public VerifyPrescriptionResult()
        {
        }
        public VerifyPrescriptionResult(int code, String msg) : base(code, msg) { }

    }



}