using System;
using System.Collections.Generic;

namespace resultAll
{
    [Serializable]
    class BatchQueryB2CCarrierResult : BaseResult{
        public BatchQueryB2CCarrierResult() {
        }
        public BatchQueryB2CCarrierResult(int code, String msg) : base(code,msg) {}


        private IList<CarrierResult> model;


        public IList<CarrierResult> getModel() {
            return model;
        }

        public void setModel(IList<CarrierResult> model) {
            this.model = model;
        }

    }



}