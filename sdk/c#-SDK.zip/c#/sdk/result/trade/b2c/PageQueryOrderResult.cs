using System;
using System.Collections.Generic;

namespace resultAll
{
    [Serializable]
    class PageQueryOrderResult : PageResult 
    {
        public PageQueryOrderResult()
        {
        }
        public PageQueryOrderResult(int? code, String msg) : base(code, msg) { }


        private IList<TradeFullResult> model;


        public IList<TradeFullResult> getModel()
        {
            return model;
        }

        public void setModel(IList<TradeFullResult> model)
        {
            this.model = model;
        }


    }



}