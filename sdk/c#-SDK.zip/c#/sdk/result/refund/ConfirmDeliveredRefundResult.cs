using System;

namespace resultAll
{
    [Serializable]
    class ConfirmDeliveredRefundResult : BaseResult 
    {
        public ConfirmDeliveredRefundResult()
        {
        }
        public ConfirmDeliveredRefundResult(int? code, String msg) : base(code, msg) { }


    }



}