using System;

namespace resultAll
{
    [Serializable]
    class RejectRefundResult : BaseResult 
    {
        public RejectRefundResult()
        {
        }
        public RejectRefundResult(int? code, String msg) : base(code, msg) { }


    }



}