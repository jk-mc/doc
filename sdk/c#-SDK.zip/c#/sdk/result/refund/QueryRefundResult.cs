using System;

namespace resultAll
{
    [Serializable]
    class QueryRefundResult : BaseResult 
    {
        public QueryRefundResult()
        {
        }
        public QueryRefundResult(int? code, String msg) : base(code, msg) { }


        private RefundResult model;


        public RefundResult getModel()
        {
            return model;
        }

        public void setModel(RefundResult model)
        {
            this.model = model;
        }


    }



}