using System;

namespace resultAll
{
    [Serializable]
    class ReceivedRefundResult : BaseResult 
    {
        public ReceivedRefundResult()
        {
        }
        public ReceivedRefundResult(int? code, String msg) : base(code, msg) { }


    }



}