using System;
using System.Collections.Generic;

namespace resultAll
{
    [Serializable]
    class PageQueryRefundByTradeIdResult : PageResult 
    {
        public PageQueryRefundByTradeIdResult()
        {
        }
        public PageQueryRefundByTradeIdResult(int? code, String msg) : base(code, msg) { }


        private IList<RefundResult> model;


        public IList<RefundResult> getModel()
        {
            return model;
        }

        public void setModel(IList<RefundResult> model)
        {
            this.model = model;
        }


    }



}