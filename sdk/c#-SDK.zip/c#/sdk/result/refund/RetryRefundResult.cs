using System;

namespace resultAll
{
    [Serializable]
    class RetryRefundResult : BaseResult 
    {
        public RetryRefundResult()
        {
        }
        public RetryRefundResult(int? code, String msg) : base(code, msg) { }


    }



}