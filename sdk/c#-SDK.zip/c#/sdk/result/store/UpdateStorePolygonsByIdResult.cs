using System;

namespace resultAll
{
    [Serializable]
    class UpdateStorePolygonsByIdResult : BaseResult
    {
        public UpdateStorePolygonsByIdResult()
        {
        }
        public UpdateStorePolygonsByIdResult(int code, String msg) : base(code, msg) { }

    }



}