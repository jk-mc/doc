using System;

namespace resultAll
{
    [Serializable]
    class UpdateStoreStatusResult : BaseResult
    {
        public UpdateStoreStatusResult()
        {
        }
        public UpdateStoreStatusResult(int code, String msg) : base(code, msg) { }

    }



}