using System;

namespace resultAll
{
    [Serializable]
    class UpdatePriceResult : BaseResult
    {
        public UpdatePriceResult()
        {
        }
        public UpdatePriceResult(int code, String msg) : base(code, msg) { }

    }



}