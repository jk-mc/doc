using System;
using System.Collections.Generic;

namespace resultAll
{
    [Serializable]
    class BatchQuerySellerCategoryResult : BaseResult
    {
        public BatchQuerySellerCategoryResult()
        {
        }
        public BatchQuerySellerCategoryResult(int code, String msg) : base(code, msg) { }


        private IList<AuthorizeCategoryResult> model;

        public IList<AuthorizeCategoryResult> getModel()
        {
            return model;
        }

        public void setModel(IList<AuthorizeCategoryResult> model)
        {
            this.model = model;
        }

    }



}