using System;

namespace resultAll
{
    [Serializable]
    class ItemSearchSpuResult
    {
        private long? spuId;

        private String title;

        private int? status;

        private String pictureUrl;

        private int? skuCount;

        private String brandName;

        private String isSecKill;

        private String isCspu;

        private String createdTime;

        private String modifiedTime;


        public long? getSpuId()
        {
            return spuId;
        }

        public void setSpuId(long? spuId)
        {
            this.spuId = spuId;
        }

        public String getTitle()
        {
            return title;
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public int? getStatus()
        {
            return status;
        }

        public void setStatus(int? status)
        {
            this.status = status;
        }

        public String getPictureUrl()
        {
            return pictureUrl;
        }

        public void setPictureUrl(String pictureUrl)
        {
            this.pictureUrl = pictureUrl;
        }

        public int? getSkuCount()
        {
            return skuCount;
        }

        public void setSkuCount(int? skuCount)
        {
            this.skuCount = skuCount;
        }

        public String getBrandName()
        {
            return brandName;
        }

        public void setBrandName(String brandName)
        {
            this.brandName = brandName;
        }

        public String getIsSecKill()
        {
            return isSecKill;
        }

        public void setIsSecKill(String isSecKill)
        {
            this.isSecKill = isSecKill;
        }

        public String getIsCspu()
        {
            return isCspu;
        }

        public void setIsCspu(String isCspu)
        {
            this.isCspu = isCspu;
        }

        public String getCreatedTime()
        {
            return createdTime;
        }

        public void setCreatedTime(String createdTime)
        {
            this.createdTime = createdTime;
        }

        public String getModifiedTime()
        {
            return modifiedTime;
        }

        public void setModifiedTime(String modifiedTime)
        {
            this.modifiedTime = modifiedTime;
        }



    }


}