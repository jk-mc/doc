using System;

namespace resultAll
{
    [Serializable]
    class ItemSkuResult
    {
        private long? spuId;

        private long? skuId;
        private string outerSkuId;
        private int? status;
        private long? sellPrice;
        private long? origPrice;
        private String pictureUrl;
        private String isLockStock;
        private String isLockPrice;
        private String specValues;
        private String createdTime;
        private String modifiedTime;

        public long? getSpuId()
        {
            return spuId;
        }

        public void setSpuId(long? spuId)
        {
            this.spuId = spuId;
        }

        public long? getSkuId()
        {
            return skuId;
        }

        public void setSkuId(long? skuId)
        {
            this.skuId = skuId;
        }

        public String getOuterSkuId()
        {
            return outerSkuId;
        }

        public void setOuterSkuId(String outerSkuId)
        {
            this.outerSkuId = outerSkuId;
        }

        public int? getStatus()
        {
            return status;
        }

        public void setStatus(int? status)
        {
            this.status = status;
        }

        public long? getSellPrice()
        {
            return sellPrice;
        }

        public void setSellPrice(long? sellPrice)
        {
            this.sellPrice = sellPrice;
        }

        public long? getOrigPrice()
        {
            return origPrice;
        }

        public void setOrigPrice(long? origPrice)
        {
            this.origPrice = origPrice;
        }

        public String getPictureUrl()
        {
            return pictureUrl;
        }

        public void setPictureUrl(String pictureUrl)
        {
            this.pictureUrl = pictureUrl;
        }

        public String getIsLockStock()
        {
            return isLockStock;
        }

        public void setIsLockStock(String isLockStock)
        {
            this.isLockStock = isLockStock;
        }

        public String getIsLockPrice()
        {
            return isLockPrice;
        }

        public void setIsLockPrice(String isLockPrice)
        {
            this.isLockPrice = isLockPrice;
        }

        public String getSpecValues()
        {
            return specValues;
        }

        public void setSpecValues(String specValues)
        {
            this.specValues = specValues;
        }



        public String getCreatedTime()
        {
            return createdTime;
        }

        public void setCreatedTime(String createdTime)
        {
            this.createdTime = createdTime;
        }

        public String getModifiedTime()
        {
            return modifiedTime;
        }

        public void setModifiedTime(String modifiedTime)
        {
            this.modifiedTime = modifiedTime;
        }



    }


}