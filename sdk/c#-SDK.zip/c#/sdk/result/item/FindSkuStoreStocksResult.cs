using System;
using System.Collections.Generic;

namespace resultAll
{
    [Serializable]
    class FindSkuStoreStocksResult : BaseResult
    {
        public FindSkuStoreStocksResult()
        {
        }
        public FindSkuStoreStocksResult(int code, String msg) : base(code, msg) { }

        private IList<SkuStoreStockResult> model;

        public IList<SkuStoreStockResult> getModel()
        {
            return model;
        }

        public void setModel(IList<SkuStoreStockResult> model)
        {
            this.model = model;
        }


    }



}