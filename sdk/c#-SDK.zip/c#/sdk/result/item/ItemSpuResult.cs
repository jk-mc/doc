using System;
using System.Collections.Generic;

namespace resultAll
{
    [Serializable]
    class ItemSpuResult
    {
        private long? spuId;
        private String title;
        private String outerSpuId;
        private int? status;
        private int? type;
        private int? subType;
        private long? brandId;
        private String brandName;
        private long? firmId;
        private String firmName;
        private String specKeys;
        private String approvalNo;
        private String pictureUrl;
        private String articleNo;
        private int? orderQty;
        private String createdTime;
        private String modifiedTime;
        private IList<ItemSkuResult> itemSkus;

        public long? getSpuId()
        {
            return spuId;
        }

        public void setSpuId(long? spuId)
        {
            this.spuId = spuId;
        }

        public String getTitle()
        {
            return title;
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public String getOuterSpuId()
        {
            return outerSpuId;
        }

        public void setOuterSpuId(String outerSpuId)
        {
            this.outerSpuId = outerSpuId;
        }

        public int? getStatus()
        {
            return status;
        }

        public void setStatus(int? status)
        {
            this.status = status;
        }

        public int? getType()
        {
            return type;
        }

        public void setType(int? type)
        {
            this.type = type;
        }

        public int? getSubType()
        {
            return subType;
        }

        public void setSubType(int? subType)
        {
            this.subType = subType;
        }

        public long? getBrandId()
        {
            return brandId;
        }

        public void setBrandId(long? brandId)
        {
            this.brandId = brandId;
        }

        public String getBrandName()
        {
            return brandName;
        }

        public void setBrandName(String brandName)
        {
            this.brandName = brandName;
        }

        public long? getFirmId()
        {
            return firmId;
        }

        public void setFirmId(long? firmId)
        {
            this.firmId = firmId;
        }

        public String getFirmName()
        {
            return firmName;
        }

        public void setFirmName(String firmName)
        {
            this.firmName = firmName;
        }

        public String getSpecKeys()
        {
            return specKeys;
        }

        public void setSpecKeys(String specKeys)
        {
            this.specKeys = specKeys;
        }

        public String getApprovalNo()
        {
            return approvalNo;
        }

        public void setApprovalNo(String approvalNo)
        {
            this.approvalNo = approvalNo;
        }

        public String getPictureUrl()
        {
            return pictureUrl;
        }

        public void setPictureUrl(String pictureUrl)
        {
            this.pictureUrl = pictureUrl;
        }

        public String getArticleNo()
        {
            return articleNo;
        }

        public void setArticleNo(String articleNo)
        {
            this.articleNo = articleNo;
        }

        public int? getOrderQty()
        {
            return orderQty;
        }

        public void setOrderQty(int? orderQty)
        {
            this.orderQty = orderQty;
        }

        public String getCreatedTime()
        {
            return createdTime;
        }

        public void setCreatedTime(String createdTime)
        {
            this.createdTime = createdTime;
        }

        public String getModifiedTime()
        {
            return modifiedTime;
        }

        public void setModifiedTime(String modifiedTime)
        {
            this.modifiedTime = modifiedTime;
        }

        public IList<ItemSkuResult> getItemSkus()
        {
            return itemSkus;
        }

        public void setItemSkus(IList<ItemSkuResult> itemSkus)
        {
            this.itemSkus = itemSkus;
        }





    }


}