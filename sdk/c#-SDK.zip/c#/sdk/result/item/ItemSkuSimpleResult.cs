using System;

namespace resultAll
{
    [Serializable]
    class ItemSkuSimpleResult
    {
        private long? spuId;
        private String spuOuterId;
        private long? skuId;
        private String skuOuterId;

        public long? getSpuId()
        {
            return spuId;
        }

        public void setSpuId(long? spuId)
        {
            this.spuId = spuId;
        }

        public String getSpuOuterId()
        {
            return spuOuterId;
        }

        public void setSpuOuterId(String spuOuterId)
        {
            this.spuOuterId = spuOuterId;
        }

        public long? getSkuId()
        {
            return skuId;
        }

        public void setSkuId(long? skuId)
        {
            this.skuId = skuId;
        }

        public String getSkuOuterId()
        {
            return skuOuterId;
        }

        public void setSkuOuterId(String skuOuterId)
        {
            this.skuOuterId = skuOuterId;
        }




    }


}