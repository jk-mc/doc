using System;
using System.Collections;
using resultAll;

namespace requestAll 
{
    interface IRequest<T> where T:BaseResult {

        IList getData();
        String getApiId();
        String getApiName();
        String getApiGroup();

        Type getClassName();
    }


}