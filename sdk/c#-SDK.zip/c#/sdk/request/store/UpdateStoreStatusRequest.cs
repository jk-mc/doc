using System;
using System.Collections;

using resultAll;

namespace requestAll
{


    class UpdateStoreStatusRequest : IRequest<UpdateStoreStatusResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "updateStoreStatus";
        private String apiId = "1576d7892ccb7833bd6f45690b031431";

        private long? sellerId;
        private String storeReferId;
        private String status;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getStoreReferId()
        {
            return storeReferId;
        }

        public void setStoreReferId(String storeReferId)
        {
            this.storeReferId = storeReferId;
        }

        public String getStatus()
        {
            return status;
        }

        public void setStatus(String status)
        {
            this.status = status;
        }



        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(storeReferId);
            list.Add(status);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(UpdateStoreStatusResult);
        }

    }
}