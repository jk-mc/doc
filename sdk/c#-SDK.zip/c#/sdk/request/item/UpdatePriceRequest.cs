using System;
using System.Collections;

using resultAll;

namespace requestAll
{


    class UpdatePriceRequest : IRequest<UpdatePriceResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "updatePrice";
        private String apiId = "7cbb253647549c2b9613149dbce0c4a5";

        private long? sellerId;
        private long? skuId;
        private long? storeId;
        private String storeReferId;
        private String priceType;
        private long? price;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public long? getSkuId()
        {
            return skuId;
        }

        public void setSkuId(long? skuId)
        {
            this.skuId = skuId;
        }

        public long? getStoreId()
        {
            return storeId;
        }

        public void setStoreId(long? storeId)
        {
            this.storeId = storeId;
        }

        public String getStoreReferId()
        {
            return storeReferId;
        }

        public void setStoreReferId(String storeReferId)
        {
            this.storeReferId = storeReferId;
        }

        public String getPriceType()
        {
            return priceType;
        }

        public void setPriceType(String priceType)
        {
            this.priceType = priceType;
        }


        public long? getPrice()
        {
            return price;
        }

        public void setPrice(long? price)
        {
            this.price = price;
        }


        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(skuId);
            list.Add(storeId);
            list.Add(storeReferId);
            list.Add(priceType);
            list.Add(price);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(UpdatePriceResult);
        }

    }
}