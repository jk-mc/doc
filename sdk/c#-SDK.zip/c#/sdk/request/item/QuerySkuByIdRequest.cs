using System;
using System.Collections;

using resultAll;

namespace requestAll
{


    class QuerySkuByIdRequest : IRequest<QuerySkuByIdResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "querySkuById";
        private String apiId = "6e0dacc60ae199b96240be9ae00dd937";

        private long? sellerId;
        private long? skuId;


        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public long? getSkuId()
        {
            return skuId;
        }

        public void setSkuId(long? skuId)
        {
            this.skuId = skuId;
        }






        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(skuId);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(QuerySkuByIdResult);
        }

    }
}