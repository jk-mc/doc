using System;
using System.Collections.Generic;
using System.Collections;

using resultAll;

namespace requestAll
{


    class ListSkuRequest : IRequest<ListSkuResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "listSku";
        private String apiId = "de594726855da2c3cda54afe560a5a01";

        private long? sellerId;
        private long? skuId;


        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public long? getSkuId()
        {
            return skuId;
        }

        public void setSkuId(long? skuId)
        {
            this.skuId = skuId;
        }






        public IList getData()
        {
            IList list = new ArrayList();
            
            String json = "{\"sellerId\":"+sellerId+ ",\"skuId\":"+skuId+"}";
            list.Add(json);
            
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(ListSkuResult);
        }

    }
}