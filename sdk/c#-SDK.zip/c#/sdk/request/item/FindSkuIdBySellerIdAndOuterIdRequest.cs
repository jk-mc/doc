using System;
using System.Collections.Generic;
using System.Collections;

using queryAll;
using resultAll;

namespace requestAll
{


    class FindSkuIdBySellerIdAndOuterIdRequest : IRequest<FindSkuIdBySellerIdAndOuterIdResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "findSkuIdBySellerIdAndOuterId";
        private String apiId = "9bb2ce64b32f5dd1faac57fb99ec3e84";

        private long? sellerId;
        private IList<String> skuOuterIds;


        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }




       
        public IList<String> getSkuOuterIds()
        {
            return skuOuterIds;
        }

        public void setSkuOuterIds(IList<String> skuOuterIds)
        {
            this.skuOuterIds = skuOuterIds;
        }






        public IList getData()
        {
            IList list = new ArrayList();

            FindSkuIdBySellerIdAndOuterIdParam param = new FindSkuIdBySellerIdAndOuterIdParam();
            param.setSellerId(sellerId);
            param.setSkuOuterIds(skuOuterIds);
            list.Add(param);
            
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(FindSkuIdBySellerIdAndOuterIdResult);
        }

    }
}