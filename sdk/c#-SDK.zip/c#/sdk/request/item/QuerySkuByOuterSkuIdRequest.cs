using System;
using System.Collections;

using resultAll;

namespace requestAll
{


    class QuerySkuByOuterSkuIdRequest : IRequest<QuerySkuByOuterSkuIdResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "querySkuByOuterSkuId";
        private String apiId = "9154e11e637027bc0a9d7d281b6e2124";

        private long? sellerId;
        private String outerSkuId;


        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getOuterSkuId()
        {
            return outerSkuId;
        }

        public void setOuterSkuId(String outerSkuId)
        {
            this.outerSkuId = outerSkuId;
        }






        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(outerSkuId);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(QuerySkuByOuterSkuIdResult);
        }

    }
}