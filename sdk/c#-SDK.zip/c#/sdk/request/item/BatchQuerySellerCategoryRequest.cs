using System;
using resultAll;
using System.Collections;

namespace requestAll
{


    class BatchQuerySellerCategoryRequest : IRequest<BatchQuerySellerCategoryResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "batchQuerySellerCategory";
        private String apiId = "10f1e1abcbf276da37223d5b54bbee7b";

        private long? sellerId;

        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

       






        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);

            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(BatchQuerySellerCategoryResult);
        }

    }
}