using System;
using System.Collections;

using resultAll;

namespace requestAll
{


    class QuerySpuByIdRequest : IRequest<QuerySpuByIdResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "querySpuById";
        private String apiId = "dbd954fe92410223b8bfa6b3b2d3a262";

        private long? sellerId;
        private long? spuId;


        public long? getSellerId()
        {
            return sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public long? getSpuId()
        {
            return spuId;
        }

        public void setSpuId(long? spuId)
        {
            this.spuId = spuId;
        }





        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(spuId);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(QuerySpuByIdResult);
        }

    }
}