using System;
using System.Collections.Generic;
using System.Collections;

using queryAll;
using resultAll;

namespace requestAll
{


    class SetSkuStorePricesRequest : IRequest<SetSkuStorePricesResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "setSkuStorePrices";
        private String apiId = "fddd6b8a683e388ee7b9b53591191366";

        private long? sellerId;
        private long? storeId;
        private String storeOuterId;
        private IList<SkuStorePriceParam> skuStorePriceList;


        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public long? getStoreId()
        {
            return storeId;
        }

        public void setStoreId(long? storeId)
        {
            this.storeId = storeId;
        }

        public String getStoreOuterId()
        {
            return storeOuterId;
        }

        public void setStoreOuterId(String storeOuterId)
        {
            this.storeOuterId = storeOuterId;
        }

        public IList<SkuStorePriceParam> getSkuStorePriceList()
        {
            return skuStorePriceList;
        }

        public void setSkuStorePriceList(IList<SkuStorePriceParam> skuStorePriceList)
        {
            this.skuStorePriceList = skuStorePriceList;
        }




        public IList getData()
        {
            IList list = new ArrayList();
            SetSkuStorePricesParam param = new SetSkuStorePricesParam();
            param.setSellerId(sellerId);
            param.setStoreId(storeId);
            param.setStoreOuterId(storeOuterId);
            param.setSkuStorePriceList(skuStorePriceList);
            list.Add(param);

            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(SetSkuStorePricesResult);
        }

    }
}