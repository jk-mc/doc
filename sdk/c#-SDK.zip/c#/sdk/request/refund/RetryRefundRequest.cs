using System;
using System.Collections;

using resultAll;

namespace requestAll
{


    class RetryRefundRequest : IRequest<RetryRefundResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "retryRefund";
        private String apiId = "0e58743153571ac2cc2b554d6fb3d715";

        private long sellerId;
        private String refundId;
        
        public long getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getRefundId() {
            return refundId;
        }

        public void setRefundId(String refundId) {
            this.refundId = refundId;
        }


        public IList getData()
        {
           IList list = new ArrayList();
            
            String json = "{\"sellerId\":"+sellerId+ ",\"refundId\":\""+refundId+"\"}";
            list.Add(json);

            return list;
        }

        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(RetryRefundResult);
        }

    }
}