using System;
using System.Collections;

using queryAll;
using resultAll;


namespace requestAll
{

    class ReceivedRefundRequest : IRequest<ReceivedRefundResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "receivedRefund";
        private String apiId = "44c284ba6d16a88bc8c195d20503b4ad";


        private long sellerId;
        private String refundId;
        private String prov;
        private String city;
        private String area;
        private String address;
        private String name;
        private String phone;
        public long getSellerId() {
            return sellerId;
        }

        public void setSellerId(long sellerId) {
            this.sellerId = sellerId;
        }

        public String getRefundId() {
            return refundId;
        }

        public void setRefundId(String refundId) {
            this.refundId = refundId;
        }

        public String getProv() {
            return prov;
        }

        public void setProv(String prov) {
            this.prov = prov;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getArea() {
            return area;
        }

        public void setArea(String area) {
            this.area = area;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }


        public IList getData()
        {
            IList list = new ArrayList();

            ReceivedRefundParam param  =new ReceivedRefundParam();
            param.setSellerId(sellerId);
            param.setRefundId(refundId);
            param.setProv(prov);
            param.setCity(city);
            param.setArea(area);
            param.setAddress(address);
            param.setName(name);
            param.setPhone(phone); 
            list.Add(param);

            return list;
        }

        public string getApiId()
        {
            return this.apiId;
        }
        public string getApiName()
        {
            return this.apiName;
        }
        public string getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(ReceivedRefundResult);
        }

    }
}