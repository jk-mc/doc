using System;
using System.Collections;

using resultAll;

namespace requestAll
{


    class AcceptRefundRequest : IRequest<AcceptRefundResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "acceptRefund";
        private String apiId = "034dfe681f145d4a0f7aa25e49167e22";

        private long sellerId;
        private String refundId;
        
        public long getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getRefundId() {
            return refundId;
        }

        public void setRefundId(String refundId) {
            this.refundId = refundId;
        }


        public IList getData()
        {
           IList list = new ArrayList();
            
            String json = "{\"sellerId\":"+sellerId+ ",\"refundId\":\""+refundId+"\"}";
            list.Add(json);

            return list;
        }

        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(AcceptRefundResult);
        }

    }
}