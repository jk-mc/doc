using System;
using System.Collections;

using resultAll;


namespace requestAll
{


    class RejectRefundRequest : IRequest<RejectRefundResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "rejectRefund";
        private String apiId = "ed31bc50c6896de1cfcbf1a652a4eb87";

        private long sellerId;
        private String refundId;
        private String reason;
        
        public long getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getRefundId() {
            return refundId;
        }

        public void setRefundId(String refundId) {
            this.refundId = refundId;
        }

        public String getReason() {
            return reason;
        }

        public void setReason(String reason) {
            this.reason = reason;
        }


        public IList getData()
        {
           IList list = new ArrayList();
            
            String json = "{\"sellerId\":"+sellerId 
            + ",\"refundId\":\""+refundId+"\""
            + ",\"reason\":\""+reason+"\""
            +"}";
            list.Add(json);

            return list;
        }

        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(RejectRefundResult);
        }

    }
}