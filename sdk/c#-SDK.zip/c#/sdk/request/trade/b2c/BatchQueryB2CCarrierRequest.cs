using System;
using resultAll;
using System.Collections;

namespace requestAll
{

    
    class BatchQueryB2CCarrierRequest : IRequest<BatchQueryB2CCarrierResult>
    { 
        private String apiGroup = "shennong";
        private String apiName = "batchQueryB2CCarrier";
        private String apiId = "2810e9c32c2174278ea5920c35608873";



        public IList getData(){
            IList list = new ArrayList();
            return list;
        }
        public String getApiId(){
            return this.apiId;
        }
        public String getApiName(){
            return this.apiName;
        }
        public String getApiGroup(){
            return this.apiGroup;
        }

        public Type getClassName(){
            return typeof(BatchQueryB2CCarrierResult);
        }

    }
}