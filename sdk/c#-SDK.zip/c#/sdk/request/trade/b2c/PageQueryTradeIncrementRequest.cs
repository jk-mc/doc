using System;
using System.Collections;

using resultAll;
using queryAll;

namespace requestAll
{


    class PageQueryTradeIncrementRequest : IRequest<PageQueryTradeIncrementResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "pageQueryTradeIncrement";
        private String apiId = "a0188f5e3e29be7b16cfb97f03f032e1";

        private long sellerId;
        private String startTime;
        private String endTime;
        private String status;
        private int pageNo;
        private int pageSize;

        public long getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getStartTime()
        {
            return this.startTime;
        }

        public void setStartTime(String startTime)
        {
            this.startTime = startTime;
        }

        public String getEndTime()
        {
            return this.endTime;
        }

        public void setEndTime(String endTime)
        {
            this.endTime = endTime;
        }


        public String getStatus()
        {
            return this.status;
        }

        public void setStatus(String status)
        {
            this.status = status;
        }

    
        public int getPageNo()
        {
            return this.pageNo;
        }

        public void setPageNo(int pageNo)
        {
            this.pageNo = pageNo;
        }


        public int getPageSize()
        {
            return this.pageSize;
        }

        public void setPageSize(int pageSize)
        {
            this.pageSize = pageSize;
        }

        public IList getData()
        {
            IList list = new ArrayList();

            PageQueryTradeParam param = new PageQueryTradeParam();
            param.setSellerId(sellerId);
            param.setStartTime(startTime);
            param.setEndTime(endTime);
            param.setStatus(status);
            param.setPageNo(pageNo);
            param.setPageSize(pageSize);
            list.Add(param);
            
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(PageQueryTradeIncrementResult);
        }

    }
}