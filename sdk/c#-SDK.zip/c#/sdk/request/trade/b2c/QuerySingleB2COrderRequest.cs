using System;
using resultAll;
using System.Collections;

namespace requestAll
{


    class QuerySingleB2COrderRequest : IRequest<SingleQueryOrderResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "querySingleB2COrderForOpenApi";
        private String apiId = "0a296dafe841090172ee80af2307087c";

        private long? sellerId;
        private String tradeId;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getTradeId()
        {
            return tradeId;
        }

        public void setTradeId(String tradeId)
        {
            this.tradeId = tradeId;
        }



        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(tradeId);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(SingleQueryOrderResult);
        }

    }
}