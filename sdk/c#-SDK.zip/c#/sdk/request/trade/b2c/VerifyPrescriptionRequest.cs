using System;
using resultAll;
using System.Collections;

namespace requestAll
{


    class VerifyPrescriptionRequest : IRequest<VerifyPrescriptionResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "verifyPrescription";
        private String apiId = "4853b5e0bac42eab185338dccdf38f18";

        private long? sellerId;
        private String tradeId;
        private int? verifyStatus;
        private String verifyMsg;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getTradeId()
        {
            return tradeId;
        }

        public void setTradeId(String tradeId)
        {
            this.tradeId = tradeId;
        }

        public int? getVerifyStatus()
        {
            return verifyStatus;
        }

        public void setVerifyStatus(int? verifyStatus)
        {
            this.verifyStatus = verifyStatus;
        }

        public String getVerifyMsg()
        {
            return verifyMsg;
        }

        public void setVerifyMsg(String verifyMsg)
        {
            this.verifyMsg = verifyMsg;
        }


        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(tradeId);
            list.Add(verifyStatus);
            list.Add(verifyMsg);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(VerifyPrescriptionResult);
        }

    }
}