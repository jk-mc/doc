using System;
using resultAll;
using System.Collections;

namespace requestAll
{


    class PageQueryOrderRequest : IRequest<PageQueryOrderResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "pageQueryB2COrderForOpenApi";
        private String apiId = "e4e0475234a625f4f78ca7477296b396";

        private long? sellerId;
        private long? startTime;
        private long? endTime;
        private String orderStatus;
        private String orderType;
        private int? pageNo;
        private int? pageSize;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public long? getStartTime()
        {
            return this.startTime;
        }

        public void setStartTime(long? startTime)
        {
            this.startTime = startTime;
        }

        public long? getEndTime()
        {
            return this.endTime;
        }

        public void setEndTime(long? endTime)
        {
            this.endTime = endTime;
        }


        public String getOrderStatus()
        {
            return this.orderStatus;
        }

        public void setOrderStatus(String orderStatus)
        {
            this.orderStatus = orderStatus;
        }

        public String getOrderType()
        {
            return orderType;
        }

        public void setOrderType(String orderType)
        {
            this.orderType = orderType;
        }


        public int? getPageNo()
        {
            return this.pageNo;
        }

        public void setPageNo(int? pageNo)
        {
            this.pageNo = pageNo;
        }


        public int? getPageSize()
        {
            return this.pageSize;
        }

        public void setPageSize(int? pageSize)
        {
            this.pageSize = pageSize;
        }

        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(startTime);
            list.Add(endTime);
            list.Add(orderStatus);
            list.Add(orderType);
            list.Add(pageNo);
            list.Add(pageSize);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(PageQueryOrderResult);
        }

    }
}