using System;
using resultAll;
using System.Collections;

namespace requestAll
{


    class UpdateEmsRequest : IRequest<UpdateEmsResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "updateEMS";
        private String apiId = "9d923900e2c909c387efb586090441ad";

        private long? sellerId;
        private String tradeId;
        private long? carrierId;
        private String trackingNumber;
        private String @operator;

        public long? getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long? sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getTradeId()
        {
            return tradeId;
        }

        public void setTradeId(String tradeId)
        {
            this.tradeId = tradeId;
        }

        public long? getCarrierId()
        {
            return carrierId;
        }

        public void setCarrierId(long? carrierId)
        {
            this.carrierId = carrierId;
        }

        public String getTrackingNumber()
        {
            return trackingNumber;
        }

        public void setTrackingNumber(String trackingNumber)
        {
            this.trackingNumber = trackingNumber;
        }

        public String getOperator()
        {
            return @operator;
        }

        public void setOperator(String @operator)
        {
            this.@operator = @operator;
        }


        public IList getData()
        {
            IList list = new ArrayList();
            list.Add(sellerId);
            list.Add(tradeId);
            list.Add(carrierId);
            list.Add(trackingNumber);
            list.Add(@operator);
            return list;
        }
        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(UpdateEmsResult);
        }

    }
}