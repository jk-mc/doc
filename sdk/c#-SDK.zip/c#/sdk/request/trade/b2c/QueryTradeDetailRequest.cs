using System;
using System.Collections;

using resultAll;
using queryAll;

namespace requestAll
{


    class QueryTradeDetailRequest : IRequest<QueryTradeDetailResult>
    {
        private String apiGroup = "shennong";
        private String apiName = "queryTradeDetail";
        private String apiId = "d2d3eb1f3286bd2a9f1d9b77aa35d3b3";

        private long sellerId;
        private String tradeId;
        
        public long getSellerId()
        {
            return this.sellerId;
        }

        public void setSellerId(long sellerId)
        {
            this.sellerId = sellerId;
        }

        public String getTradeId() {
            return tradeId;
        }

        public void setTradeId(String tradeId) {
            this.tradeId = tradeId;
        }


        public IList getData()
        {
           IList list = new ArrayList();
            
            String json = "{\"sellerId\":"+sellerId+ ",\"tradeId\":\""+tradeId+"\"}";
            list.Add(json);

            return list;
        }

        public String getApiId()
        {
            return this.apiId;
        }
        public String getApiName()
        {
            return this.apiName;
        }
        public String getApiGroup()
        {
            return this.apiGroup;
        }

        public Type getClassName()
        {
            return typeof(QueryTradeDetailResult);
        }

    }
}