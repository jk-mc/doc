﻿using System;
using resultAll;
using requestAll;
using queryAll;
using commonUtil;

using System.Runtime.Serialization.Json;
using System.IO;
using System.Text; 
using System.Collections;
using System.Collections.Generic;


namespace netSdk2
{
    class Program
    {
        static void Main(string[] args)
        {
            //string partnerId = "yaofang_test_03";
            //string key = "d2d03a99b8227686aaa7d47a4535419a";

            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient = new JkClient(partnerId,key,env);
            
            //testCancelOrder(jkClient);
            //testBatchQueryCarrier(jkClient);
            //testGoodReceived(jkClient);
            //testPageQueryOrder(jkClient);
            //testQueryPrescriptionFile(jkClient);
            //testSingleB2COrder(jkClient);
            //testUpateStoreBusinessHours(jkClient);
            //testJson();
            //testUpdateStorePolygonsById(jkClient);
            //testUpdateStoreStatus(jkClient);
            //testBatchQuerySellerCategory(jkClient);
            //testDelistSku(jkClient);
            //testListSku(jkClient);
            //tetFindSkuStoreStocks(jkClient);
            //testFindSkuIdBySellerIdAndOuterId(jkClient);
            //testSetSkuStorePrices();
            //testSetSkuStoreStocks();
            //testQueryDetail();  
            //testQueryRefund();
            //testPageQueryRefundIncrement();
            //testPageQueryRefundByTradeId();
            //testRejectRefund();
            //testReceivedRefund();
            //testConfirmDeliveredRefund();
            //testAcceptRefund();
            testRetryRefund();
            Console.WriteLine("Hello World!");
        }

        private static void testRetryRefund(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient2 = new JkClient(partnerId,key,env);
            RetryRefundRequest request = new RetryRefundRequest();
            request.setSellerId(21319590608L);
            request.setRefundId("1316110709");
            RetryRefundResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));  
        }

        private static void testAcceptRefund(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient2 = new JkClient(partnerId,key,env);
            AcceptRefundRequest request = new AcceptRefundRequest();
            request.setSellerId(21319590608L);
            request.setRefundId("1316110709");
            AcceptRefundResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));  
        }

        private static void testConfirmDeliveredRefund(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient2 = new JkClient(partnerId,key,env);
            ConfirmDeliveredRefundRequest request = new ConfirmDeliveredRefundRequest();
            request.setSellerId(21319590608L);
            request.setRefundId("1316110709");

            ConfirmDeliveredRefundResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));  
        }

        private static void testReceivedRefund(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient2 = new JkClient(partnerId,key,env);
            ReceivedRefundRequest request = new ReceivedRefundRequest();
            request.setSellerId(21319590608L);
            request.setRefundId("1316110709");
            request.setProv("上海市");
            request.setCity("上海市");
            request.setArea("徐汇区");
            request.setAddress("大王小路300号");
            request.setName("李大亏");
            request.setPhone("13131313113");
            ReceivedRefundResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));  
        }

        private static void testRejectRefund(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient2 = new JkClient(partnerId,key,env);
            RejectRefundRequest request = new RejectRefundRequest();
            request.setSellerId(21319590608L);
            request.setRefundId("1316100709");
            request.setReason("c#reason");

            RejectRefundResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));  
        }
 
        private static void testPageQueryRefundByTradeId(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient2 = new JkClient(partnerId,key,env);
            PageQueryRefundByTradeIdRequest request = new PageQueryRefundByTradeIdRequest();
            request.setSellerId(21319590608L);
            request.setTradeId("10023580709");
            request.setPageNo(1);
            request.setPageSize(5);

            PageQueryRefundByTradeIdResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));  
        }

        private static void testPageQueryRefundIncrement(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient2 = new JkClient(partnerId,key,env);
            PageQueryRefundIncrementRequest request = new PageQueryRefundIncrementRequest();
            request.setSellerId(21319590608L);
            request.setStatus("ALL");
            request.setStartTime("2018-05-31 00:00:00");
            request.setEndTime("2018-06-01 00:00:00");
            request.setPageNo(1);
            request.setPageSize(5);

            PageQueryRefundIncrementResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));  
        }

        private static void testQueryRefund(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient2 = new JkClient(partnerId,key,env);
            QueryRefundRequest request = new QueryRefundRequest();
            request.setSellerId(21319590608L);
            request.setRefundId("1311200709");

            QueryRefundResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));  
        }

        private static void testQueryDetail(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient2 = new JkClient(partnerId,key,env);
            QueryTradeDetailRequest request = new QueryTradeDetailRequest();
            request.setSellerId(21319590608L);
            request.setTradeId("10038740709");

            QueryTradeDetailResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));  
        }
        private static void testSetSkuStorePrices(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest(); 
            JkClient jkClient2 = new JkClient(partnerId,key,env);

            long sellerId=2523760705L;
            long storeId= 2541240602L;

            long skuId1= 911911888319149L;
            SetSkuStorePricesRequest request = new SetSkuStorePricesRequest();
            request.setSellerId(sellerId);
            request.setStoreId(storeId);
            List<SkuStorePriceParam> list = new List<SkuStorePriceParam>();
            SkuStorePriceParam param1 = new SkuStorePriceParam();
            param1.setSkuId(skuId1);
            param1.setPrice(578L);
            list.Add(param1);
            request.setSkuStorePriceList(list);
            SetSkuStorePricesResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));  

        }

        private static void testSetSkuStoreStocks(){
            String key = "0031ae2efaacd0fe644580de630f9d13";
            String partnerId = "yaofang_test_01";
            ENV env = QueryEnv.getTest();
            JkClient jkClient2 = new JkClient(partnerId,key,env);

            long sellerId=21319590608L;
            long storeId= 21329280606L;

            long skuId1= 911911888658578L;
            long skuId2= 911911888619922L;
            SetSkuStoreStocksRequest request = new SetSkuStoreStocksRequest();
            request.setSellerId(sellerId);
            request.setStoreId(storeId);
            List<SkuStoreStockParam> list = new List<SkuStoreStockParam>();
            SkuStoreStockParam param1 = new SkuStoreStockParam();
            param1.setSkuId(skuId1);
            param1.setStockNum(578L);
            list.Add(param1);
            SkuStoreStockParam param2 = new SkuStoreStockParam();
            param2.setSkuId(skuId2);
            param2.setStockNum(603);
            list.Add(param2);
            request.setSkuStoreStockList(list);
            SetSkuStoreStocksResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));
        }
        private static void testFindSkuIdBySellerIdAndOuterId(JkClient jkClient){
            FindSkuIdBySellerIdAndOuterIdRequest request = new FindSkuIdBySellerIdAndOuterIdRequest();
            request.setSellerId(21319590608L);
            List<string> list = new List<string>();
            list.Add("i8888");
            request.setSkuOuterIds(list);
            FindSkuIdBySellerIdAndOuterIdResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));   
        }

        private static void tetFindSkuStoreStocks(JkClient jkClient){
            FindSkuStoreStocksRequest request = new FindSkuStoreStocksRequest();
            request.setSellerId(21319590608L);
            request.setStoreId(21329280606L);
            IList<long?> skuIdList = new List<long?>();
            skuIdList.Add(911911888658578L);
            request.setSkuIdList(skuIdList);
            FindSkuStoreStocksResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));   
        }

        private static void testListSku(JkClient jkClient){
            ListSkuRequest request = new ListSkuRequest();
            request.setSellerId(21319590608L);
            request.setSkuId(911911888658578L);

            ListSkuResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));   
        }

        
        private static void testDelistSku(JkClient jkClient){
            DelistSkuRequest request = new DelistSkuRequest();
            request.setSellerId(21319590608L);
            request.setSkuId(911911888658578L);

            DelistSkuResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));   
        }
        private static void testBatchQuerySellerCategory(JkClient jkClient){
            BatchQuerySellerCategoryRequest request = new BatchQuerySellerCategoryRequest();
            request.setSellerId(989810607L);
            BatchQuerySellerCategoryResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));   
        }

        private static void testUpdateStoreStatus(JkClient jkClient){
            UpdateStoreStatusRequest request = new UpdateStoreStatusRequest();
            request.setSellerId(2523760705L);
            request.setStoreReferId("QMY0001123123");
            request.setStatus("close");
            UpdateStoreStatusResult result = jkClient.execute(request);

            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));   
        }
        
        private static void testUpateStoreBusinessHours(JkClient jkClient){
            UpdateStoreBusinessHoursRequest request = new UpdateStoreBusinessHoursRequest();
            request.setSellerId(2523760705L);
            request.setStoreReferId("QMY0001123123");
            request.setOpenTime("09:00");
            request.setCloseTime("20:55");
            UpdateStoreBusinessHoursResult result = jkClient.execute(request);

            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));
  

        }

        private static void testUpdateStorePolygonsById(JkClient jkClient){
            UpdateStorePolygonsByIdRequest request = new UpdateStorePolygonsByIdRequest();
            request.setSellerId(2523760705L);
            request.setStoreReferId("QMY0001123123");
            request.setPolygons("QMY0001123123");

            UpdateStorePolygonsByIdResult result = jkClient.execute(request);

            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));

            

        }

        private static void testSingleB2COrder(JkClient jkClient){
            QuerySingleB2COrderRequest request = new QuerySingleB2COrderRequest();
            request.setSellerId(989810607L);
            request.setTradeId("9660710907");
            SingleQueryOrderResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
           Console.WriteLine(JsonUtil.ToJsonString(result));
           Console.WriteLine("123");

        }

        private static void testQueryPrescriptionFile(JkClient jkClient){
            QueryPrescriptionFileForPartnerRequest request = new QueryPrescriptionFileForPartnerRequest();
            request.setSellerId(20141890502L);
            request.setTradeId("9654580208");

            QueryPrescriptionFileForPartnerResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
           Console.WriteLine(JsonUtil.ToJsonString(result));
           Console.WriteLine("123");
        }


        private static void testCancelOrder(JkClient jkClient){
            CancelOrderRequest request = new CancelOrderRequest();
            request.setSellerId(20141890502L);
            request.setTradeId("9654580208");
            request.setCancelMsg("cancelMsg");

            CancelOrderResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
           Console.WriteLine(JsonUtil.ToJsonString(result));
           Console.WriteLine("123");
        }


        private static void testBatchQueryCarrier(JkClient jkClient){
            BatchQueryB2CCarrierRequest request = new BatchQueryB2CCarrierRequest();

            BatchQueryB2CCarrierResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
           Console.WriteLine(JsonUtil.ToJsonString(result));
           Console.WriteLine("123");
        }

        private static void testGoodReceived(JkClient jkClient){
            GoodsReceivedRequest request = new GoodsReceivedRequest();
            request.setSellerId(20141890502L);
            request.setTradeId("9654580208");
            GoodsReceivedResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));

            
        }

        private static void testPageQueryOrder(JkClient jkClient){
            PageQueryOrderRequest request = new PageQueryOrderRequest();
            request.setSellerId(989810607L);

            request.setStartTime(1524326400L);
            request.setEndTime(1524499200L);
            request.setOrderType("0");
            request.setOrderStatus("PAID");
            request.setPageNo(1);
            request.setPageSize(1);
            PageQueryOrderResult result = jkClient.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));

        }

        private static void testJson(){
            // string result = "{ \"resultCode\": \"0\", \"resultMsg\": \"resultMsg\" }"; 
            // MemoryStream ms = new MemoryStream(Encoding.Default.GetBytes(result));  
            // DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(PageQueryOrderResult));  
            // PageQueryOrderResult r = (PageQueryOrderResult)serializer.ReadObject(ms);  
            // Console.WriteLine(JsonUtil.ToJsonString(r));

             Hashtable map = new Hashtable();
                map.Add("sellerId", "sellerId");
                map.Add("skuId", "skuId");

                IList list = new ArrayList();
                Object[] os = new Object[1];
                list.Add(map);

                os[0] = map;
                for(int i=0; i<list.Count ; i++){
                    Object an = list[i];
                    ;
                    Console.WriteLine(an.GetType());
                   Console.WriteLine(JsonUtil.ToJsonString(an.GetType(),map));
                }

                for(int i=0; i<os.Length ; i++){
                    Object a = os[i];
                    string b = "2";
                    ;
                    Console.WriteLine(a.GetType());
                    Type t = a.GetType();
                   Console.WriteLine(JsonUtil.ToJsonString(t,map));
                }
                string aa = "null";
                Console.WriteLine(aa.GetType());
                

                //Console.WriteLine(JsonUtil.ToJsonString(list));

        }

        private static void  testUpdateEms(){
            string partnerId = "yaofang_test_01";
            string key = "0031ae2efaacd0fe644580de630f9d13";
            ENV env = QueryEnv.getTest();
            JkClient jkClient2 = new JkClient(partnerId,key,env);
            UpdateEmsRequest request = new UpdateEmsRequest();
            request.setSellerId(21319590608L);
            request.setTradeId("111127420709");
            request.setCarrierId(200002L);
            request.setTrackingNumber("12313124323");
            request.setOperator("operator");

            UpdateEmsResult result = jkClient2.execute(request);
            Console.WriteLine(result + "---------");
            Console.WriteLine(JsonUtil.ToJsonString(result));
        }

    }
}
